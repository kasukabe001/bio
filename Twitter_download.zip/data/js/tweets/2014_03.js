Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449892204551475200",
  "text" : "\u30AB\u30E9\u30B9\u306E\u5852\u3092\u63A2\u3059\u306B\u306F\u3001\u5852\u306B\u5E30\u308B\u30AB\u30E9\u30B9\u3092\u8FFD\u3044\u304B\u3051\u308C\u3070\u826F\u3044\u3001\u3068\u3044\u3046\u60C5\u5831\u3092Web\u304B\u3089\u5F97\u305F\u306E\u3067\u3001\u672C\u65E5\u5B9F\u884C\u306B\u79FB\u3057\u305F\u3002\u304C\u3001\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306B\u51FA\u4F1A\u3048\u306A\u304B\u3063\u305F\u3002\u6B8B\u5FF5\uFF01\u3002\u3082\u3046\u3001\u5317\u306B\u5E30\u3063\u3066\u3057\u307E\u3063\u305F\u304B\uFF1F\u3002",
  "id" : 449892204551475200,
  "created_at" : "2014-03-29 12:53:54 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449030315479031810",
  "text" : "\u6570\u65E5\u524D\u306E\u5915\u65B9\u3001\u30AB\u30E9\u30B9\u306E\u306D\u3050\u3089\u306B\u306A\u3063\u3066\u3044\u308B\u6797\u306B\u884C\u3063\u3066\u307F\u305F\u3002\u3053\u306E\u6642\u671F\u306F\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u3082\u3044\u3063\u3057\u3087\u306B\u3044\u308B\u306E\u3067\u306F\u3068\u601D\u3063\u305F\u304C\u3001\u30CF\u30B7\u30D6\u30C8\u3060\u3051100\u7FBD\u3050\u3089\u3044\u3044\u305F\u3002\u5302\u3044\u304C\u5F37\u70C8\u3060\u3063\u305F\u3002\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306E\u306D\u3050\u3089\u306F\u3069\u3053\u3060\uFF1F\u3002",
  "id" : 449030315479031810,
  "created_at" : "2014-03-27 03:49:04 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444811874773635072",
  "text" : "\u30DF\u30E4\u30DE\u30AC\u30E9\u30B970~80\u7FBD\u3002\u30B3\u30AF\u30DE\u30EB\u3044\u306A\u3044\u3002\u3059\u3050\u306B\u30DF\u30E4\u30DE\u3068\u5206\u304B\u308B\u500B\u4F53\u304A\u3089\u305A\u3002\u30CF\u30B7\u30DC\u30BD\u306A\u306E\u30DF\u30E4\u30DE\u306A\u306E\u3001\u3068\u3044\u3046\u306E\u3070\u304B\u308A\u3002\u3053\u308C\u3063\u3066\u5E7C\u9CE5\u306E\u7FA4\u308C\uFF1F\u3002\u6696\u304B\u304F\u306A\u308A\u59CB\u3081\u308B\u3068\u8B58\u5225\u306B\u82E6\u52B4\u3057\u305F\u3088\u3046\u306A\u8A18\u61B6\u304C\u6570\u5E74\u524D\u3082\u3042\u3063\u305F\u3002\u3082\u3057\u304B\u3059\u308B\u3068\u51FA\u7523\u30FB\u5B50\u80B2\u3066\u3059\u308B\u6210\u9CE5\u306F\u65E9\u3005\u3068\u5E30\u56FD\u3057\u3066\u3057\u307E\u3063\u305F\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 444811874773635072,
  "created_at" : "2014-03-15 12:26:29 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442194484483198976",
  "text" : "\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306E\u89B3\u5BDF\u306B\u51FA\u304B\u3051\u308B\u3002\u76EE\u7684\u5730\u306B\u7740\u304F\u524D\u306B\u7A7A\u3092\u65CB\u56DE\u3059\u308B\u7FA4\u308C\u3092\u767A\u898B\u3002100\u7FBD\u3050\u3089\u3044\u3002\u7530\u3093\u307C\u306B\u964D\u308A\u305F\u306E\u3067\u3001\u7FA4\u308C\u306E\u7AEF\u8FBA\u308A\u3092\u63A2\u3059\u3068\u5C0F\u3055\u3044\u500B\u4F53\u304C\u3044\u3066\u3001\u732B\u306E\u3088\u3046\u306A\u9CF4\u304D\u58F0\u3082\u805E\u3053\u3048\u308B\u3002\u8089\u773C\u3067\u306F\u3063\u304D\u308A\u3068\u30B3\u30AF\u30DE\u30EB\u30AC\u30E9\u30B92\u7FBD\uFF08\u9ED2\u8272\uFF09\u3092\u8B58\u5225\u3067\u304D\u305F\u3002\u30AB\u30E9\u30B9\u306B\u3057\u3066\u306F\u672C\u5F53\u306B\u5C0F\u3055\u3044\u3002",
  "id" : 442194484483198976,
  "created_at" : "2014-03-08 07:05:55 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]