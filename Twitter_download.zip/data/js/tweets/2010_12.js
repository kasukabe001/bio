Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18917820754567168",
  "text" : "\u6628\u65E5\u306B\u7D9A\u3044\u3066\u3001\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u8DE1\u306B\u51FA\u304B\u3051\u308B\u3002\u4ECA\u65E5\u3082\u30C4\u30B0\u30DF\u304C\u96C6\u56E3\u3067\u6C34\u6D74\u3073\u3092\u3057\u3066\u3044\u305F\u3002\u30E0\u30AF\u30C9\u30EA\u306E\u7FA4\u308C\u3082\u6C34\u6D74\u3073\u3092\u3057\u3088\u3046\u3068\u3084\u3063\u3066\u304D\u305F\u304C\u3001\u7740\u5730\u305B\u305A\u306B\u5927\u534A\u306F\u98DB\u3073\u53BB\u3063\u305F\u3002\u601D\u3044\u304C\u3051\u305A\u3001\u30B3\u30D6\u30CF\u30AF\u30C1\u30E7\u30A6\u304C\u73FE\u308C\u305F\u3002\u6C34\u9762\u3092\u8E74\u3063\u3066\u3001\u98DB\u3073\u7ACB\u3064\u59FF\u306F\u58EE\u89B3\u3060\u3063\u305F\u3002\u7FBD\u306E\u6C5A\u308C\u5177\u5408\u304B\u3089\u3057\u3066\u3001\u91CE\u751F\u3067\u751F\u6D3B\u3057\u3066\u3044\u308B\u306F\u305A\u3002",
  "id" : 18917820754567168,
  "created_at" : "2010-12-26 06:35:34 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18611946865561600",
  "text" : "\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u8DE1\u306B\u51FA\u304B\u3051\u308B\u3002\u4F8B\u306E\u30A2\u30AA\u30B5\u30AE\u304C1\u7FBD\u3002\u30D2\u30C9\u30EA\u30AC\u30E2\u304C7,8\u7FBD\u3002\u6728\u3005\u3068\u5DDD\u539F\u306E\u6C34\u969B\u3092\u30C4\u30B0\u30DF\u306E\u7FA4\u308C\u304C\u884C\u3063\u305F\u308A\u6765\u305F\u308A\u3002\u6570\u306F40,50\u7FBD\u3002\u3053\u308C\u3060\u3051\u306E\u6570\u3092\u4E00\u5EA6\u306B\u898B\u305F\u306E\u3082\u3001\u6C34\u6D74\u3073\u59FF\u3092\u898B\u305F\u306E\u3082\u521D\u3081\u3066\u3002\u7FA4\u308C\u306B\u306F\u30D2\u30E8\u30C9\u30EA\u3082\u6DF7\u3058\u3063\u3066\u3044\u305F\u3002\u982D\u90E8\u304C\u30C8\u30B5\u30AB\u306E\u3088\u3046\u306B\u7A81\u304D\u51FA\u3057\u3066\u3044\u308B\u500B\u4F532\u7FBD\u3002\u30EC\u30F3\u30B8\u30E3\u30AF?",
  "id" : 18611946865561600,
  "created_at" : "2010-12-25 10:20:08 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16380347356815360",
  "text" : "\u91CE\u9CE5\u306E\u68EE\u3067\u30AD\u30BB\u30AD\u30EC\u30A4\u3092\u898B\u305F\u3002\u68EE\u306E\u4E2D\u3068\u306F\u8A00\u3048\u3001\u65E7\u53E4\u9685\u7530\u5DDD\u304B\u30895,60m\u306E\u8DDD\u96E2\u306A\u306E\u3067\u3001\u6C34\u8FBA\u304B\u3089\u96E2\u308C\u305F\u5834\u6240\u3067\u306F\u306A\u3044\u3002\u4ECA\u5E74\u306F\u3001\u6625\u65E5\u90E8\u5E02\u5185\u3067\uFF13\u5EA6\u3082\u30AD\u30BB\u30AD\u30EC\u30A4\u3092\u898B\u305F\u3002\u6570\u304C\u5897\u3048\u3066\u3044\u308B\u306E\u3060\u308D\u3046\u304B\u3002\u3061\u306A\u307F\u306B\u6628\u5E74\u4EE5\u524D\u3068\u306A\u308B\u3068\u3001\u4ECA\u9AD8\u68213\u5E74\u306E\u606F\u5B50\u304C\u5E7C\u7A1A\u5712\u306B\u3082\u884C\u3063\u3066\u306A\u304B\u3063\u305F\u9803\u306B\u516B\u5E61\u516C\u5712\u3067\u78BA\u8A8D\u3057\u3066\u3044\u308B\u3002",
  "id" : 16380347356815360,
  "created_at" : "2010-12-19 06:32:33 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16080566214463488",
  "text" : "\u6240\u8981\u3067\u884C\u5FB3\u306B\u51FA\u304B\u3051\u305F\u3002\u5730\u56F3\u3092\u983C\u308A\u306B\u76EE\u7684\u5730\u3092\u76EE\u6307\u3057\u3066\u6B69\u3044\u3066\u3044\u308B\u3068\u3001\u30B9\u30BA\u30E1\u304C\u8DB3\u5143\u306B\u307E\u3068\u308F\u308A\u3064\u304F\u3088\u3046\u306B\u76EE\u306B\u3064\u304F\u3002\u30C1\u30E5\u30F3\u30C1\u30E5\u30F3\u3068\u3046\u308B\u3055\u3044\u3002\u5B50\u4F9B\u306E\u9803\u306B\u623B\u3063\u305F\u304B\u306E\u3088\u3046\u306B\u30B9\u30BA\u30E1\u304C\u591A\u3044\u3002\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u3068\u30E0\u30AF\u30C9\u30EA\u306F\u3044\u306A\u3044\u3002\u3053\u306E2\u7A2E\u304C\u3044\u306A\u3044\u306E\u3067\u30B9\u30BA\u30E1\u304C\u5B89\u5FC3\u3057\u3066\u66AE\u3089\u305B\u308B\u306E\u3067\u3042\u308D\u3046\u3002\u5927\u80C6\u306A\u610F\u898B\u304B\u306A\uFF1F\u3002",
  "id" : 16080566214463488,
  "created_at" : "2010-12-18 10:41:20 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]