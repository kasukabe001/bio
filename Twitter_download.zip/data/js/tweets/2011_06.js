Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "torimidasi",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79557500084551680",
  "text" : "2011.6.11 18\u6642\u9803\u3001\u81EA\u5B85\u304B\u3089100\u30E1\u30FC\u30C8\u30EB\u307B\u3069\u306E\u5730\u70B9\u3067\u4E0A\u7A7A\u3092\u98DB\u3076\u30B3\u30A2\u30B8\u30B5\u30B72\u7FBD\u3092\u78BA\u8A8D\u3002\u990C\u5834\u3068\u5852\u306E\u9593\u3092\u79FB\u52D5\u4E2D\u3060\u308D\u3046\u304B\u3002\u3053\u3093\u306A\u4F4F\u5B85\u5730\u3067\u898B\u308C\u308B\u3068\u306F\u601D\u308F\u306A\u304B\u3063\u305F\u300215\u5206\u3050\u3089\u3044\u5F8C\u306B\u3082\u30461\u7FBD\u78BA\u8A8D\u3002#torimidasi",
  "id" : 79557500084551680,
  "created_at" : "2011-06-11 14:36:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "torimidasi",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78819115183251456",
  "text" : "2011.6.9 \u81EA\u5B85\u306E\u5EAD\u304B\u3089\u30AB\u30C3\u30B3\u30A6\u3092\u898B\u305F\u3002\u9CF4\u58F0\u306B\u9A5A\u3044\u3066\u5EAD\u306B\u51FA\u3066\u307F\u305F\u3089\u3001\u96A3\u5B85\u306E\u30A2\u30F3\u30C6\u30CA\u306B\u3068\u307E\u3063\u3066\u3044\u305F\u3002\u672C\u5E74\u521D\u8A8D\u3068\u3044\u3046\u304B\u3001\u6625\u65E5\u90E8\u3067\u59FF\u3092\u898B\u305F\u306E\u306F\u521D\u3081\u3066\u3002\u3053\u308C\u307E\u3067\u306F\u9CF4\u58F0\u3060\u3051\u3060\u3063\u305F\u3002#torimidasi",
  "id" : 78819115183251456,
  "created_at" : "2011-06-09 13:41:56 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]