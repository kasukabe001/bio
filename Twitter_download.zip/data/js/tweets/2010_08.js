Grailbird.data.tweets_2010_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22163810843",
  "text" : "2010.8.26 17\u6642\u534A\u9803 \u5852\u306B\u306F\u4E00\u7FBD\u3082\u3044\u306A\u304B\u3063\u305F\u3002\u6628\u591C\u306F\u898B\u8AA4\u308A\u3067\u306F\u306A\u304B\u3063\u305F\u3002\u65E9\u304F\u3082\u653E\u68C4\u3055\u308C\u305F\u306E\u304B\u3001\u5143\u3005\u5852\u3067\u306F\u306A\u304B\u3063\u305F\u306E\u304B\u3002\u671D\u5915\u306E\u6642\u9593\u5E2F\u306B\u89B3\u5BDF\u3057\u3066\u3044\u306A\u3044\u306E\u3067\u3001\u4F55\u3068\u3082\u8A00\u3048\u306A\u3044\u3002\u305F\u3060\u3001\u6728\u3005\u306B\u6B8B\u3055\u308C\u305F\u3075\u3093\u306A\u3069\u304B\u3089\u3001\u5852\u3060\u3063\u305F\u3068\u63A8\u6E2C\u3057\u3066\u3044\u308B\u3002\u30B3\u30ED\u30CB\u30FC\u8DE1\u306B\u306F\u4F8B\u306E\u30A2\u30AA\u30B5\u30AE\u304C\u4E00\u7FBD\u3002",
  "id" : 22163810843,
  "created_at" : "2010-08-26 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22081124476",
  "text" : "2010.8.25 19\u6642\u9803 \u4E00\u7FBD\u3082\u3044\u306A\u304B\u3063\u305F\u3001\u3068\u3044\u3046\u304B\u3001\u6697\u904E\u304E\u3066\u3088\u304F\u898B\u3048\u306A\u304B\u3063\u305F\u3002\u672C\u5F53\u306B\u5852\u306A\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 22081124476,
  "created_at" : "2010-08-25 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21909238761",
  "text" : "2010.8.23 16\u6642\u534A \u30B3\u30B5\u30AE10\u3001\u30C1\u30E5\u30A6\u30B5\u30AE1\u3002\u30B5\u30AE\u306E\u5852\u306B\u306F\u590F\u5852\u3068\u51AC\u5852\u304C\u3042\u308B\u305D\u3046\u3060\u3002\u4ECA\u89B3\u5BDF\u3057\u3066\u3044\u308B\u306E\u306F\u590F\u5852\u3002\u30C1\u30E5\u30A6\u30B5\u30AE\u3068\u30C0\u30A4\u30B5\u30AE\u306F\u3053\u3053\u304B\u3089\u6E21\u308A\u306B\u65C5\u7ACB\u308A\u3001\u30B3\u30B5\u30AE\u306F\u51AC\u5852\u306B\u79FB\u52D5\u3059\u308B\u3089\u3057\u3044\u3002\u30B5\u30AE\u304C\u6B62\u307E\u3063\u3066\u3044\u308B\u3044\u308B\u306E\u306F\u7AF9\u3067\u306F\u306A\u304F\u3001\u5225\u306E\u6728\u3002\u540D\u524D\u304C\u5206\u304B\u3089\u306A\u3044\u306E\u304C\u6B8B\u5FF5\u3002",
  "id" : 21909238761,
  "created_at" : "2010-08-23 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21824983179",
  "text" : "2010.8.22 17\u6642 \u30B7\u30E9\u30B5\u30AE17\u7FBD\u30023\u7FBD\u306F\u30C1\u30E5\u30A6\u30B5\u30AE?\uFF61\u3053\u3053\u304C\u5852\u3067\u3042\u308B\u306E\u306F\u9593\u9055\u3044\u306A\u3055\u305D\u3046\u3002\u3053\u3053\u4EE5\u5916\u306B\u3082\u5852\u306F\u3042\u308B\u306F\u305A\u3060\u304C\u3001\u63A2\u3059\u306E\u306F\u5927\u5909\u3002\u3053\u306E\u5852\u306B\u3057\u307C\u3063\u3066\u89B3\u5BDF\u3092\u7D9A\u3051\u3066\u307F\u3088\u3046\u3002\u30B3\u30ED\u30CB\u30FC\u3088\u308A\u3082\u81EA\u5B85\u306B\u8FD1\u3044\u306E\u3067\u3001\u89B3\u5BDF\u306F\u5C11\u3057\u697D\u3060\u3002",
  "id" : 21824983179,
  "created_at" : "2010-08-22 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21732250890",
  "text" : "2010.8.21 14\u6642 \u5852\u306B\u306F0\u3001\u6C34\u7530\u306B1\u3002\u30B3\u30B5\u30AE\u304B\u30C1\u30E5\u30A6\u30B5\u30AE\u304B\u5224\u5225\u3067\u304D\u306A\u304B\u3063\u305F\u3002\u663C\u9593\u3060\u304B\u3089\u3044\u306A\u3044\u306E\u304B\uFF1F\u3002\u6B21\u306F\u671D\u304B\u5915\u65B9\u306B\u6765\u3066\u307F\u3088\u3046\u300215\u6642\u306B\u30B3\u30ED\u30CB\u30FC\u8DE1\u3067\u3001\u3044\u3064\u3082\u306E\u30A2\u30AA\u30B5\u30AE1\u7FBD\u3002\u3055\u3044\u305F\u307E\u5E02\u5CA9\u69FB\u533A\uFF08\u65E7\u5CA9\u69FB\u5E02\uFF09\u306E\u56F3\u66F8\u9928\u306B\u884C\u3063\u3066\u307F\u305F\u304C\u3001\u7279\u306B\u30B5\u30AE\u306B\u95A2\u3059\u308B\u66F8\u7C4D\u306F\u306A\u304B\u3063\u305F\u3002",
  "id" : 21732250890,
  "created_at" : "2010-08-21 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21626052649",
  "text" : "2010.8.20 8\u6642\u534A \u5852\u306B\u306F\u30C1\u30E5\u30A6\u30B5\u30AE4\u3001\u30B3\u30B5\u30AE2\u3002\u4ECA\u5E74\u751F\u307E\u308C\u306E\u82E5\u9CE5\u306F\u3044\u306A\u3044\u3088\u3046\u3060\u3002\u30B3\u30ED\u30CB\u30FC\u8DE1\u306B\u306F\u3044\u3064\u3082\u306E\u30A2\u30AA\u30B5\u30AE\u304C1\u7FBD\u3002\u30B3\u30ED\u30CB\u30FC\u306E\u5074\u3067\u306F\u53CC\u773C\u93E1\u3092\u6301\u3063\u3066\u3044\u3066\u3082\u602A\u3057\u307E\u308C\u306A\u3044\u304C\u3001\u5852\u306F\u9055\u3046\u3002\u30B5\u30AE\u304C\u6570\u7FBD\u7A0B\u5EA6\u3067\u306F\u4E00\u822C\u306E\u4EBA\u306E\u76EE\u306B\u306F\u3068\u307E\u3089\u305A\u3001\u53CC\u773C\u93E1\u3092\u6301\u3063\u3066\u3058\u3063\u3068\u3057\u3066\u3044\u308B\u79C1\u306F\u7ACB\u6D3E\u306A\u4E0D\u4FE1\u8005\u3002",
  "id" : 21626052649,
  "created_at" : "2010-08-20 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21571180241",
  "text" : "2010.8.19 15\u6642 \u6C17\u306B\u306A\u3063\u3066\u3044\u305F\u30B3\u30B5\u30AE\u306E\u82E5\u9CE5\u306F\u3044\u306A\u304F\u306A\u3063\u3066\u3044\u305F\u3002\u3069\u3053\u304B\u3078\u98DB\u3093\u3067\u884C\u3063\u305F\u306E\u3060\u308D\u3046\u3002\u304A\u305D\u3089\u304F\u6628\u65E5\u3068\u540C\u3058\u3067\u3042\u308D\u3046\u30A2\u30AA\u30B5\u30AE\u304C1\u7FBD\u3044\u308B\u3060\u3051\u3002\u30B7\u30E9\u30B5\u30AE\u3082\u30B4\u30A4\u30B5\u30AE\u3082\u307E\u3063\u305F\u304F\u3044\u306A\u3044\u3002\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u89B3\u5BDF\u8A18\u9332\u306F\u3053\u308C\u306B\u3066\u7D42\u4E86!\u3002",
  "id" : 21571180241,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21571579249",
  "text" : "2010.8.19 15\u6642\u534A \u30B3\u30ED\u30CB\u30FC\u6700\u5BC4\u308A\u306E\u6C34\u7530\u5730\u5E2F\u306E\u8107\u306B\u7AF9\u6797\u304C\u3042\u308B\u3002\u30B3\u30ED\u30CB\u30FC\u304B\u3089\u306E\u5E30\u308A\u306B\u898B\u3066\u307F\u308B\u3068\u3001\u30B3\u30B5\u30AE\u304C7\u7FBD\u3002\u8003\u3048\u3066\u307F\u308B\u3068\u3001\u6570\u65E5\u524D\u3082\u6C34\u7530\u3067\u306F\u306A\u304F\u6728\u3005\u306B\u6B62\u307E\u3063\u3066\u3044\u308B\u6570\u7FBD\u306E\u30B7\u30E9\u30B5\u30AE\u3092\u898B\u305F\u899A\u3048\u304C\u3042\u308B\u3002\u30B5\u30AE\u306E\u5852\u89B3\u5BDF\u8A18\u9332\u306E\u59CB\u307E\u308A\u3060!\u3002",
  "id" : 21571579249,
  "created_at" : "2010-08-19 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21445551246",
  "text" : "2010.8.18 9\u6642 A\u30D6\u30ED\u30C3\u30AF\u524D\u306E\u4E2D\u5DDE\u306B\u30B3\u30B5\u30AE\u82E5\u9CE51,\u30C1\u30E5\u30A6\u30B5\u30AE2(\u751F\u5E74\u4E0D\u8A73)\uFF64\u30A2\u30AA\u30B5\u30AE1(\u4F53\u8272\u304B\u3089\u3057\u3066\u304A\u305D\u3089\u304F\u4ECA\u5E74\u751F\u307E\u308C\uFF09\u3002\u30C1\u30E5\u30A6\u30B5\u30AE\u306F\u6B69\u3044\u305F\u308A\u3001\u306F\u3070\u305F\u3044\u305F\u308A\u3068\u5143\u6C17\u3060\u304C\u3001\u30B3\u30B5\u30AE\u306F\u3058\u3063\u3068\u3057\u3066\u3044\u308B\u3053\u3068\u304C\u591A\u3044\u3002\u5B8C\u5168\u306B\u5DE3\u7ACB\u3061\u3067\u304D\u305F\u306E\u304B\u3069\u3046\u304B\u6C17\u306B\u306A\u308B\u3002\u30A2\u30AA\u30B5\u30AE\u306E\u51FA\u73FE\u306B\u306F\u3073\u3063\u304F\u308A\u3002",
  "id" : 21445551246,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21526346311",
  "text" : "2010.8.19 \u3053\u3093\u306A\u30B5\u30A4\u30C8\u3092\u898B\u3064\u3051\u307E\u3057\u305F\u3002http:\/\/fukaya.j-eagle.com\/?page_id=1492\u3000\u57FC\u7389\u3001\u7B2C3\u306E\u30B3\u30ED\u30CB\u30FC\u3002",
  "id" : 21526346311,
  "created_at" : "2010-08-18 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21372691101",
  "text" : "2010.8.16 16\u6642\u534A \u5230\u7740\u6642\u306B\u306F\u30B3\u30B5\u30AE1\u7FBD\u3060\u3051\u3002\u30D1\u30E9\u30D1\u30E9\u3068\u623B\u3063\u3066\u6765\u30665\u7FBD\u306B\u3002\u30B3\u30B5\u30AE\u3068\u30C1\u30E5\u30A6\u30B5\u30AE\u306E\u82E5\u9CE5\u304C\u54041\u3001\u6B8B\u308A3\u7FBD\u306F\u30C0\u30A4\u30B5\u30AE\u30FB\u30C1\u30E5\u30A6\u30B5\u30AE\u306E\u3044\u305A\u308C\u304B\u3067\u3001\u82E5\u9CE5\u304B\u3069\u3046\u304B\u306F\u5224\u5B9A\u4E0D\u80FD\u3002\u9CE5\u898B\u306E\u5BB6\u65CF\u9023\u308C\u306B\u6628\u65E5\u307E\u3067\u306F\u305F\u304F\u3055\u3093\u3044\u305F\u3068\u6559\u3048\u3066\u3042\u3052\u305F\u3002\u3069\u3053\u306B\u884C\u3063\u305F\u306E\u3068\u805E\u304B\u308C\u305F\u304C\u3001\u7B54\u3048\u3089\u308C\u306A\u3044\u3002",
  "id" : 21372691101,
  "created_at" : "2010-08-17 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21232864869",
  "text" : "2010.8.15 16\u6642\u534A \u30B7\u30E9\u30B5\u30AE\u7D0440\u7FBD\u3002\u30B3\u30B5\u30AE\u306F1\u7FBD\u3060\u3051\u3002\u96C6\u56E3\u3067\u4E00\u6589\u306B\u7A7A\u3092\u821E\u3063\u305F\u306E\u3067\u3073\u3063\u304F\u308A!\u3002\u65C5\u7ACB\u3061\u306E\u6E96\u5099\u304B?\uFF61B\u30D6\u30ED\u30C3\u30AF\u306F1\u7FBD\u3060\u3051\u3067\u3001\u4ED6\u306F\u7686A\u30D6\u30ED\u30C3\u30AF\u3002\u6B8B\u3063\u3066\u3044\u308B\u30B5\u30AE\u306F\u4E00\u6589\u306B\u3044\u306A\u304F\u306A\u308B\u306E\u3060\u308D\u3046\u304B\u3002\u305D\u308C\u3068\u3082\u3001\u30C1\u30E5\u30A6\u30B5\u30AE\u3001\u30C0\u30A4\u30B5\u30AE\u306E\u9806\u3067\u3044\u306A\u304F\u306A\u308B\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 21232864869,
  "created_at" : "2010-08-15 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21047947331",
  "text" : "2010.8.13 16\u6642\u534A \u30B7\u30E9\u30B5\u30AE\u7D0470\u7FBD\u3002\uFF22\u30D6\u30ED\u30C3\u30AF\u306B\u306F1\u7FBD\u3082\u3044\u306A\u304B\u3063\u305F\u3002\uFF21\u30D6\u30ED\u30C3\u30AF\u524D\u306E\u652F\u6D41\u3092\u9694\u3066\u305F\u4E2D\u5DDE\u306E\u6A39\u4E0A\u306B10\u6570\u7FBD\u3044\u305F\u3002\u30C0\u30A4\u30B5\u30AE\u306F\u304B\u3089\u3060\u304C\u5927\u304D\u3044\u306E\u3067\u3088\u304F\u76EE\u7ACB\u3064\u30023\u5BB6\u65CF\uFF1F\u3002\u982D\u90E8\u304C\u6BDB\u7FBD\u7ACB\u3063\u305F\u30D2\u30CA\u306E\u9762\u5F71\u3092\u6B8B\u3059\u82E5\u9CE5\u304C\u3044\u308B\u5DE3\u304C3\u3064\u3050\u3089\u3044\u3002\u89B3\u5BDF\u4E2D\u306B\u30AB\u30EB\u30AC\u30E21\u7FBD\u304C\u98DB\u6765\u3002",
  "id" : 21047947331,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21048049383",
  "text" : "2010.8.13 \u8FFD\u4F38 \u89B3\u5BDF\u5730\u306B\u5411\u304B\u3046\u9014\u4E2D\u306E\u6C34\u7530\u3067\u30B3\u30B5\u30AE3\u3001\u30C1\u30E5\u30A6\u30B5\u30AE1\u3092\u78BA\u8A8D\u3002\u4ECA\u5E74\u751F\u307E\u308C\u306E\u82E5\u9CE5\u3067\u306F\u306A\u304B\u3063\u305F\u3002\u96FB\u7DDA\u306B\u30E0\u30AF\u30C9\u30EA\u304C100\u7FBD\u3050\u3089\u3044\u7FA4\u308C\u3066\u3044\u305F\u3002",
  "id" : 21048049383,
  "created_at" : "2010-08-13 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20866618367",
  "text" : "2010.8.10 16\u6642\u9803 \u82E5\u9CE5\u30B0\u30EB\u30FC\u30D7\u304C\u6CB3\u539F\u304B\u3089\uFF21\u30D6\u30ED\u30C3\u30AF\u306E\u6A39\u4E0A\u306B\u79FB\u52D5\u3002\u9060\u304F\u304B\u3089\u898B\u308B\u3068\u3001\u6728\u306E\u679D\u3005\u306B\u767D\u3044\u5927\u304D\u306A\u82B1\u304C\u54B2\u3044\u305F\u3088\u3046\u3067\u3001\u306A\u304B\u306A\u304B\u58EE\u89B3\u3002\u30B7\u30E9\u30B5\u30AE\u306F60\u7FBD\u5F37\u3002\u30B4\u30A4\u30B5\u30AE\u306F0\u3002\u89AA\u9CE5\u304C\u30B3\u30ED\u30CB\u30FC\u306B\u623B\u3063\u3066\u304F\u308B\u3068\u3001\u5927\u9A12\u304E\u3057\u3066\u8FCE\u3048\u308B\u30D2\u30CA\uFF08\u82E5\u9CE5\uFF09\u304C\uFF21\u30D6\u30ED\u30C3\u30AF\u306B\u307E\u3060\u3044\u305F\u3002",
  "id" : 20866618367,
  "created_at" : "2010-08-11 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20463181715",
  "text" : "2010.8.6 16\u6642\u9803 \u6CB3\u539F\u306E\u82E5\u9CE5\u30B0\u30EB\u30FC\u30D7\u306E\u30E1\u30F3\u30D0\u30FC\u304C\u5897\u3048\u3066\u3044\u305F\u3002\u5915\u65E5\u304C\u7729\u3057\u304F\u3066\u53CC\u773C\u93E1\u304C\u4F7F\u3048\u306A\u3044\u6642\u523B\u3002\u30B3\u30ED\u30CB\u30FC\u306F\u307B\u307C\u5F79\u5272\u3092\u7D42\u3048\u305F\u3068\u3044\u3046\u611F\u3058\u3002\u30B4\u30A4\u30B5\u30AE\u306F\u4E00\u7FBD\u3082\u3044\u306A\u3044\u3002\u79C1\u306E\u6A2A\u306E\u6797\u3067\u30C4\u30AF\u30C4\u30AF\u30DC\u30A6\u30B7\u304C\u9CF4\u3044\u3066\u3044\u305F\u3002",
  "id" : 20463181715,
  "created_at" : "2010-08-06 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20379739346",
  "text" : "2010.8.5 14:30 \u82E5\u9CE5\u3001\u89AA\u9CE5\u3092\u542B\u3081\u3066\u30B7\u30E9\u30B5\u30AE\u7D0480\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE0\u3002\u82E5\u9CE5\u304C\u3068\u3069\u307E\u3063\u3066\u3044\u308B\u5DE3\u306FA\u30D6\u30ED\u30C3\u30AF\u306B\u4E00\u3064\u3002\u82E5\u9CE5\u3089\u3057\u3044\u306E\u304C\u3068\u3069\u307E\u3063\u3066\u3044\u308B\u5DE3\u304C\u4E21\u30D6\u30ED\u30C3\u30AF\u306B\u4E00\u3064\u305A\u3064\u3002\u82E5\u9CE5\u30B0\u30EB\u30FC\u30D7\u306F\u76F8\u5909\u308F\u3089\u305A\u3001\u6CB3\u539F\u306E\u65E5\u9670\u306B\u305F\u3080\u308D\u3002\u591C\u306E\u30B3\u30F3\u30D3\u30CB\u524D\u306B\u305F\u3080\u308D\u3059\u308B\u30D2\u30C8\u306E\u82E5\u8005\u306E\u3088\u3046\u3002",
  "id" : 20379739346,
  "created_at" : "2010-08-05 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20184649320",
  "text" : "2010.8.2 \u3053\u3093\u306A\u30D6\u30ED\u30B0\u3092\u898B\u3064\u3051\u307E\u3057\u305F\u3002http:\/\/blog.goo.ne.jp\/makko0609\/e\/6403fd12a7729fdd4852839c51493857\n\u3053\u306E\u30B3\u30ED\u30CB\u30FC\u306F3\u5E74\u524D\u304B\u3089\u3042\u3063\u305F\u3089\u3057\u3044\u3002",
  "id" : 20184649320,
  "created_at" : "2010-08-03 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20031544925",
  "text" : "2010.7.31 \u8FFD\u4F38\u8A02\u6B63 \u30B3\u30ED\u30CB\u30FC\u304B\u3089\u7D044Km\u4E0A\u6D41(\u5317\u897F)\u306B\u884C\u3063\u305F\u5730\u70B9\u306B\u307E\u3068\u307E\u3063\u305F\u6C34\u7530\u5730\u5E2F\u304C\u3042\u308B\u3002\u30B3\u30B5\u30AE\u3068\u30C1\u30E5\u30A6\u30B5\u30AE\u3042\u308F\u305B\u30667,8\u7FBD\u3044\u305F\u304C\u3001\u4ECA\u5E74\u751F\u307E\u308C\u306E\u500B\u4F53\u306F\u3044\u306A\u304B\u3063\u305F\u3088\u3046\u306B\u601D\u3046\u30028\u7FBD\u3082\u30D2\u30CA\u3092\u3064\u308C\u305F\u30AD\u30B8\u306E\u592B\u5A66\u3068\u3001\u4ECA\u5E74\u5DE3\u7ACB\u3063\u305F\u30AA\u30AA\u30E8\u30B7\u30AD\u30EA1\u7FBD\u306B\u51FA\u4F1A\u3063\u305F\u3002",
  "id" : 20031544925,
  "created_at" : "2010-08-01 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20053060905",
  "text" : "2010.8.1 17\u6642 \u5915\u65B9\u306E\u305F\u3081\u304B\u30B5\u30AE\u304C\u591A\u3044\u3002\u30B7\u30E9\u30B5\u30AE\u7D04110\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE5\u7FBD\u3002\u3082\u3061\u308D\u3093\u82E5\u9CE5\u3082\u30AB\u30A6\u30F3\u30C8\u3057\u3066\u3044\u308B\u3002\u30B3\u30ED\u30CB\u30FC\u6700\u5BC4\u306E\u6C34\u7530\u5730\u5E2F\u306B\u306F\u5927\u4E2D\u5C0F\u3042\u308F\u305B\u306610\u7FBD\u7A0B\u5EA6\u306E\u30B7\u30E9\u30B5\u30AE\u30021\u7FBD\u304C\u990C\u3092\u3068\u3089\u305A\u306B\u6C34\u7530\u5074\u306E\u6728\u306B\u6B62\u307E\u3063\u3066\u3044\u308B\u3002\u5634\u306E\u5468\u308A\u306F\u8D64\u304F\u3001\u8DB3\u306F\u8584\u3044\u9EC4\u7DD1\u3002\u5DE3\u7ACB\u3061\u9593\u3082\u306A\u3044\u30B3\u30B5\u30AE\u304B\u3002",
  "id" : 20053060905,
  "created_at" : "2010-08-01 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20053281251",
  "text" : "2010.8.1 \u8FFD\u4F38 \u30A2\u30DE\u30B5\u30AE\u30921\u7FBD\u78BA\u8A8D\u3002\u30A2\u30DE\u30B5\u30AE\u306F\u5B50\u80B2\u3066\u3057\u305F\u306E\u3060\u308D\u3046\u304B\uFF1F\u3002\u30A2\u30DE\u30B5\u30AE\u306E\u96DB\u306F\u89AA\u3068\u9055\u3044\u4E9C\u9EBB\u8272\u3067\u306F\u306A\u3044\u3002\u3068\u304D\u3069\u304D\u3001\u5634\u304C\u592A\u3044\u3068\u611F\u3058\u308B\u30D2\u30CA\u304C\u3044\u305F\u304C\u3001\u305D\u308C\u304C\u30A2\u30DE\u30B5\u30AE\u306E\u96DB\u3060\u3063\u305F\u306E\u3060\u308D\u3046\u304B\u3002\u4E9C\u9EBB\u8272\u306E\u89AA\u9CE5\u304C\u30A8\u30B5\u3092\u4E0E\u3048\u3066\u3044\u308B\u5834\u9762\u3092\u898B\u308B\u3053\u3068\u306F\u306A\u304B\u3063\u305F\u304C\u3001\u7E41\u6B96\u3057\u305F\u3068\u8003\u3048\u308B\u65B9\u304C\u81EA\u7136\u3060\u3002",
  "id" : 20053281251,
  "created_at" : "2010-08-01 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]