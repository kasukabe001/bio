Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554244321155633152",
  "text" : "\u672C\u65E5\u306F\u30DF\u30E4\u30DE\u30AB\u30E9\u30B9\u306B\u51FA\u4F1A\u3048\u305A\u3002\u66FF\u308F\u308A\u3068\u3044\u3046\u308F\u3051\u3067\u3082\u306A\u3044\u304C\u3001\uFF13\u5E74\u3076\u308A\u306B\u30AF\u30A4\u30CA\u306B\u906D\u9047\u3002",
  "id" : 554244321155633152,
  "created_at" : "2015-01-11 11:51:58 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550570771613880323",
  "text" : "\u4ECA\u30B7\u30FC\u30BA\u30F3\u3001\u6700\u521D\u306E\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u89B3\u5BDF\u3002\u6700\u521D\u3001\u30CF\u30B7\u30DC\u30BD\u3057\u304B\u3044\u306A\u304B\u3063\u305F\u304C\u3001\u9060\u65B9\u306B\u30AB\u30E9\u30B9\u306E\u7FA4\u308C\u3092\u767A\u898B\u3057\u3001\u8FD1\u3065\u3044\u3066\u898B\u308B\u3068\u30DF\u30E4\u30DE\u3060\u3063\u305F\u3002\u7D04200\u7FBD\u3002\u9BAE\u3084\u304B\u306B\u304F\u3061\u3070\u3057\u767D\u3057\uFF01\u3002\u5BD2\u304B\u3063\u305F\uFF01\u3002",
  "id" : 550570771613880323,
  "created_at" : "2015-01-01 08:34:35 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]