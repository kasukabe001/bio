Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29240849166",
  "text" : "2010.10.27 19\u6642\u9803 \u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u306E\u5852\u306E\u4E0B\u3092\u901A\u308B\u3002\u3053\u306E\u65E5\u3082\u9759\u304B\u3002\u3057\u304B\u3057\u3001\u30E6\u30EA\u30CE\u30AD\u306E\u8449\u9670\u306B\u3058\u3063\u3068\u3001\u3068\u307E\u3063\u3066\u3044\u308B\u30CF\u30AF\u30BB\u30A4\u30EC\u30A4\u3092\u4F55\u7FBD\u3082\u78BA\u8A8D\u3067\u304D\u305F\u3002\u6BCE\u65E5\u3001\u89B3\u5BDF\u3057\u305F\u3044\u304C\u3064\u3044\u3064\u3044\u3055\u307C\u308A\u304C\u3061\u3002",
  "id" : 29240849166,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28012557347",
  "text" : "10\u670817\u65E5\u306B\u6E21\u826F\u702C\u904A\u6C34\u5730\u306B\u51FA\u304B\u3051\u305F\u3002\u8466\u539F\u306E\u4E0A\u3092\u98DB\u3076\u30C1\u30E5\u30A6\u30D2\u3092\u78BA\u8A8D\u3067\u304D\u305F\u3002\u3086\u3063\u304F\u308A\u306F\u3070\u305F\u304D\u306A\u304C\u3089\u3001\u4F4E\u7A7A\u3092\u821E\u3046\u306E\u304C\u5370\u8C61\u7684\u3060\u3063\u305F\u3002",
  "id" : 28012557347,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28378119649",
  "text" : "2010.10.21 20\u6642\u9803 \u8FD1\u6240\u306E\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u306E\u5852\u306E\u5074\u3092\u901A\u308B\u3002\u8857\u8DEF\u6A39\u3092\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u304C\u5852\u3068\u3057\u3066\u5229\u7528\u4E2D\u3002\u591C\u306B\u901A\u308A\u304B\u304B\u308B\u3068\u3001\u9CF4\u304D\u308F\u3081\u304F\u306E\u3084\u3089\u98DB\u3073\u56DE\u308B\u306E\u3084\u3089\u3067\u9A12\u304C\u3057\u3044\u3053\u3068\u3053\u306E\u4E0A\u306A\u3044\u3002\u3057\u304B\u3057\u3001\u3053\u306E\u65E5\u306F\u9759\u304B\u3002\u76EE\u3092\u51DD\u3089\u3057\u3066\u307F\u308B\u3068\u3001\u8449\u3063\u3071\u306E\u5F71\u306B\u305F\u304F\u3055\u3093\u3044\u305F\u3002\u5C31\u5BDD\u6642\u523B\u3092\u904E\u304E\u305F\u304B\u3089\u3060\u308D\u3046\u304B\uFF1F\u3002",
  "id" : 28378119649,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26055769554",
  "text" : "\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u8DE1\u306B\u884C\u3063\u3066\u307F\u305F\u3002\u6CB3\u539F\u306E\u69D8\u5B50\u304C\u3060\u3044\u3076\u5909\u308F\u3063\u3066\u3044\u305F\u3002\u30AB\u30EB\u30AC\u30E2\u304C10\u7FBD\u3050\u3089\u3044\u3044\u305F\u306E\u3067\u3001\u53CC\u773C\u93E1\u3067\u898B\u3066\u307F\u305F\u3002\u30B3\u30AC\u30E2\u304C1\u7FBD\u6DF7\u3058\u3063\u3066\u3044\u305F\u3002\u30E1\u30B9\uFF1F\u3001\u30AA\u30B9\u306E\u30A8\u30AF\u30EA\u30D7\u30B9\uFF1F\u3002\u5224\u5225\u4E0D\u80FD\u3002",
  "id" : 26055769554,
  "created_at" : "2010-10-01 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]