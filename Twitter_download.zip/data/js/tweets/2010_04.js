Grailbird.data.tweets_2010_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12856863262",
  "text" : "2010.4.26 \u30D2\u30E8\u30C9\u30EA\u3001\u30AD\u30B8\u30D0\u30C8\u3001\u30AB\u30EB\u30AC\u30E22\u7FBD\uFF08\u3044\u3064\u3082\u306E\u6CBC\uFF09",
  "id" : 12856863262,
  "created_at" : "2010-04-26 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12810336913",
  "text" : "2010.4.25 \u30B3\u30AC\u30E24\u7FBD(\u65E7\u53E4\u9685\u7530\u5DDD)",
  "id" : 12810336913,
  "created_at" : "2010-04-25 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12148780381",
  "text" : "2010.4.14 \u30B3\u30B5\u30AE1\u7FBD(\u8C4A\u6625\u5C0F\u305D\u3070)",
  "id" : 12148780381,
  "created_at" : "2010-04-14 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11678522676",
  "text" : "2010.4.6 \u30C4\u30D0\u30E11\u7FBD(\u6625\u65E5\u90E8\u99C5\u8FD1\u304F\uFF09\u672C\u5E74\u521D\u8A8D",
  "id" : 11678522676,
  "created_at" : "2010-04-06 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]