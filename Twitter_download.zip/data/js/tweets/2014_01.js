Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427423180974616576",
  "text" : "\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306E\u7FA4\u308C\u3001230~250\u7FBD\u3050\u3089\u3044\u3002\u5468\u8FBA\u306B\u30CF\u30B7\u30DC\u30BD\u30AC\u30E9\u30B9\u3082\u3044\u308B\u306E\u3067\u3001\u3084\u3084\u3053\u3057\u3044\u3002\u731B\u70C8\u306A\u98A8\u3067\u7802\u5D50\u72B6\u614B\u306B\u306A\u3063\u305F\u306E\u3067\u3001\u9000\u6563\u3002",
  "id" : 427423180974616576,
  "created_at" : "2014-01-26 12:50:02 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424436442396250113",
  "text" : "\u8FD1\u6240\u306E\u7530\u3093\u307C\u3067\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306E\u7FA4\u308C\u3092\u898B\u308B\u3002200\u7FBD\u3050\u3089\u3044\u3002\u3061\u3087\u3046\u3069\u982D\u4E0A\u3067\u65CB\u56DE\u3057\u3066\u304F\u308C\u305F\u3002\u821E\u3044\u4E0A\u304C\u3063\u305F\u308A\u3001\u6728\u306E\u8449\u306E\u3088\u3046\u306B\u821E\u3044\u964D\u308A\u305F\u308A\u3068\u3001\u58EE\u89B3\u3060\u3063\u305F\u3002\u30B3\u30AF\u30DE\u30EB\u306B\u306F\u51FA\u4F1A\u3048\u306A\u304B\u3063\u305F\u304B\u3063\u305F\u304C\u3001\u826F\u3057\u3068\u3057\u3088\u3046\u3002",
  "id" : 424436442396250113,
  "created_at" : "2014-01-18 07:01:48 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423827886760407040",
  "text" : "\u4E00\u6628\u65E5\u306B\u7D9A\u3044\u3066\u3001\u4E5D\u6BB5\u4E0B\u99C5\u5074\u306E\u304A\u5800\u3067\u9CE5\u898B\u3002\u30CF\u30B7\u30D3\u30ED\u30AC\u30E2\u306F\u304A\u3068\u3068\u3044\u3068\u540C\u3058\u5834\u6240\u306B100\u7FBD\u3050\u3089\u3044\u3044\u305F\u3002",
  "id" : 423827886760407040,
  "created_at" : "2014-01-16 14:43:37 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423089972275470336",
  "text" : "\u4ED5\u4E8B\u306E\u6253\u3061\u5408\u308F\u305B\u3067\u4E0A\u4EAC\u3002\u6B66\u9053\u9928\u306B\u8FD1\u3044\u304A\u5800\u3067\u9CE5\u898B\u3057\u305F\u3002\u30CF\u30B7\u30D3\u30ED\u30AC\u30E2\u7D0430\u7FBD\u3001\u30D2\u30C9\u30EA\u30AC\u30E25\u7FBD\u3001\u30AB\u30EB\u30AC\u30E28\u7FBD\u3002\u30A2\u30AA\u30B5\u30AE\u3001\u30AB\u30A4\u30C4\u30D6\u30EA\u3001\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u3001\u30B9\u30BA\u30E1\u3001\u30AB\u30EF\u30E9\u30D2\u30EF\u3001\u30D2\u30E8\u30C9\u30EA\u3001\u30AD\u30B8\u30D0\u30C8\u3002\u3053\u306E\u5800\u3067\u30CF\u30B7\u30D3\u30ED\u30AC\u30E2\u3092\u898B\u305F\u306E\u306F\u521D\u3081\u3066\u3002\u3053\u308C\u307E\u3067\u306F\u96A3\u306E\u5800\u3067\u3057\u304B\u898B\u305F\u3053\u3068\u304C\u306A\u304B\u3063\u305F\u3002",
  "id" : 423089972275470336,
  "created_at" : "2014-01-14 13:51:24 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421631151451566081",
  "text" : "\u30AB\u30E9\u30B9\u306F\u30E2\u30F3\u30B4\u30EB\u8A9E\u3067\u306Fxepee\u3067\u306F\u306A\u304Fx\u044Dp\u044D\u044D\u3060\u3063\u305F\u3002Web\u3067\u8ABF\u3079\u305F\u3089\u30E2\u30F3\u30B4\u30EB\u306B\u306F\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u3082\u30B3\u30AF\u30DE\u30EB\u30AC\u30E9\u30B9\u3082\u3044\u3066\u3001\u51AC\u306B\u306A\u308B\u3068\u671D\u9BAE\u534A\u5CF6\u3084\u65E5\u672C\u306B\u6E21\u3063\u3066\u304D\u3066\u3044\u308B\u305D\u3046\u3060\u3002\u3046\u3061\u306E\u8FD1\u6240\u306B\u6765\u3066\u3044\u308B\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u305F\u3061\u306F\u30E2\u30F3\u30B4\u30EB\u304B\u3089\u6765\u305F\u306E\u3060\u308D\u3046\u304B\u3002\u30E2\u30F3\u30B4\u30EB\u8A9E\u3067\u5C0B\u306D\u305F\u3089\u7B54\u3048\u3066\u304F\u308C\u308B\u304B\u306A\u3002",
  "id" : 421631151451566081,
  "created_at" : "2014-01-10 13:14:34 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421589477467762688",
  "text" : "\u30AB\u30E9\u30B9\u306F\u30E2\u30F3\u30B4\u30EB\u8A9E\u3067xepee(\u30D8\u30EC\u30FC\uFF09\u3001\u6E80\u6D32\u8A9E\u3067gaha\u3002\u6E80\u6D32\u8A9E\u306E\u521D\u7B49\u6559\u80B2\u30D3\u30C7\u30AA\u5185\u306E\u30AB\u30E9\u30B9\u306E\u5199\u771F\u306F\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u3060\u3063\u305F\u3002\u30E2\u30F3\u30B4\u30EB\u306B\u3082\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306F\u3044\u308B\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 421589477467762688,
  "created_at" : "2014-01-10 10:28:58 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420534102391930880",
  "text" : "\u4E38\uFF12\u5E74\u30C4\u30A4\u30FC\u30C8\u3057\u3066\u3044\u306A\u304B\u3063\u305F\u3002\u4E00\u6628\u65E5\u3001\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\uFF08\u7D04160\u7FBD\uFF09\u306E\u7FA4\u308C\u3092\u78BA\u8A8D\u3002\u4E21\u7FFC\u306E\u88CF\u306E\u90E8\u5206\u304C\u7FBD\u3044\u306E\u306F\u3044\u305F\u304C\u3001\u30B3\u30AF\u30DE\u30EB\u3067\u306F\u306A\u3044\u3002",
  "id" : 420534102391930880,
  "created_at" : "2014-01-07 12:35:17 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]