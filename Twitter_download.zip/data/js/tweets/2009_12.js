Grailbird.data.tweets_2009_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7151712296",
  "text" : "2009.12.29 \u91CE\u9CE5\u306E\u68EE\u30A2\u30AA\u30B81\u3001\u30B7\u30ED\u30CF\u30E91",
  "id" : 7151712296,
  "created_at" : "2009-12-29 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7116257974",
  "text" : "2009.12.28 \u65E7\u53E4\u9685\u7530\u5DDD \u30A2\u30AA\u30B81 \u91CE\u9CE5\u306E\u68EE\u30C1\u30E7\u30A6\u30B2\u30F3\u30DD\u30A61(4\u65E5\u9023\u7D9A)",
  "id" : 7116257974,
  "created_at" : "2009-12-28 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7015926737",
  "text" : "2009.12.25 \u3044\u3064\u3082\u306E\u6CBC \u30C1\u30E7\u30A6\u30B2\u30F3\u30DD\u30A61\u3001\u30B7\u30E1\u3089\u3057\u304D\u9CF4\u58F0\u3001\u30E1\u30B8\u30ED\u9CF4\u58F0",
  "id" : 7015926737,
  "created_at" : "2009-12-25 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6982033034",
  "text" : "2009.12.24 \u65E7\u53E4\u9685\u7530\u5DDD\uFF08\u8C4A\u6625\u5C0F\u4ED8\u8FD1\uFF09\u30AB\u30EF\u30BB\u30DF1 \u91CE\u9CE5\u306E\u68EE\u30B3\u30B2\u30E91\u30D2\u30AC\u30E9?\u30E1\u30B8\u30ED",
  "id" : 6982033034,
  "created_at" : "2009-12-24 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6961046082",
  "text" : "2009.12.23 \u3044\u3064\u3082\u306E\u6CBC\u3067\u30E2\u30BA1\u30B7\u30E11\u30B3\u30B2\u30E91\u3001\u30AD\u30B8\u30D0\u30C8\uFF65\u30D2\u30E8\u30C9\u30EA\uFF65\u30B7\u30B8\u30E5\u30A6\u30AB\u30E9\u3001\u30AB\u30EB\u30AC\u30E26",
  "id" : 6961046082,
  "created_at" : "2009-12-23 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6909059224",
  "text" : "2009.12.22\u3000\u3044\u3064\u3082\u306E\u6CBC\u306E\u8868\u9762\u306E\uFF17\u5272\u3050\u3089\u3044\u51CD\u7D50\u3002\u30AB\u30EB\u30AC\u30E25\uFF8A",
  "id" : 6909059224,
  "created_at" : "2009-12-21 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6854978987",
  "text" : "\u65E7\u53E4\u9685\u7530\u5DDD\uFF08\u8C4A\u6625\u5C0F\u4ED8\u8FD1\uFF09\u3067\u30E2\u30BA\u3001\u30C4\u30B0\u30DF\u3001\u30D2\u30E8\u30C9\u30EA\u3001\u30B7\u30B8\u30E5\u30A6\u30AB\u30E9\u3001\u30E1\u30B8\u30ED\u3001\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4",
  "id" : 6854978987,
  "created_at" : "2009-12-20 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6874712265",
  "text" : "2009.12.21   \u65E7\u53E4\u9685\u7530\u5DDD\uFF08\u8C4A\u6625\u5C0F\u4ED8\u8FD1\uFF09\u30B3\u30AC\u30E2\uFF14\u7FBD\u3001\u91CE\u9CE5\u306E\u68EE\u30E2\u30BA1\u7FBD",
  "id" : 6874712265,
  "created_at" : "2009-12-20 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6791298009",
  "text" : "\u65E7\u53E4\u9685\u7530\u5DDD\u3067\u30B3\u30AC\u30E2\uFF13\u7FBD\u3002",
  "id" : 6791298009,
  "created_at" : "2009-12-18 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6688170440",
  "text" : "\u3044\u3064\u3082\u306E\u6CBC\u3067\u30AB\u30EB\u30AC\u30E213\u7FBD\u3002",
  "id" : 6688170440,
  "created_at" : "2009-12-15 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twtr.jp\" rel=\"nofollow\"\u003EKeitai Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6622098756",
  "text" : "\u30B7\u30B8\u30E5\u30A6\u30AB\u30E92\u7FBD\u3002\u4E0A\u86ED\u7530\u3002",
  "id" : 6622098756,
  "created_at" : "2009-12-13 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6643628085",
  "text" : "\u30B9\u30BA\u30E1\u306E\u7FA4\u308C\u306B\u30E1\u30B8\u30ED\u304C1\u7FBD\u6DF7\u3058\u3063\u3066\u3044\u305F\u3002\u3044\u3064\u3082\u306E\u6CBC\u3067\u30A6\u30B0\u30A4\u30B91\u3001\u30B7\u30ED\u30CF\u30E9\u3089\u3057\u304D\u9CF4\u304D\u58F0\u3002\u30B7\u30E1\u3089\u3057\u304D\u9CE5\u3082\u3002\u8C4A\u6625\u99C5\u8FD1\u304F\u3067\u30C1\u30E7\u30A6\u30B2\u30F3\u30DD\u30A6\uFF11\u7FBD\u3002\u96A3\u5BB6\u306E\u5EAD\u306B\u30A2\u30AA\u30B8\uFF1F\u3002",
  "id" : 6643628085,
  "created_at" : "2009-12-13 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6588112864",
  "text" : "\u81EA\u5B85\u306E\u5EAD\u306B\u30D2\u30E8\u30C9\u30EA\u3001\u30E1\u30B8\u30ED\u3002\u305D\u3057\u3066\u30C4\u30B0\u30DF\u3082\u3002",
  "id" : 6588112864,
  "created_at" : "2009-12-12 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6396512467",
  "text" : "\u30C4\u30B0\u30DF\u3092\uFF13\u7FBD\uFF08\u3044\u3064\u3082\u306E\u6CBC\uFF09\u3001\u30B8\u30E7\u30A6\u30D3\u30BF\u30AD\u3092\u30DA\u30A2\u3067\u78BA\u8A8D\uFF08\u5357\u4E2D\u66FD\u6839\uFF09\u30002009.12.6",
  "id" : 6396512467,
  "created_at" : "2009-12-06 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]