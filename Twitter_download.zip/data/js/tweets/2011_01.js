Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30093714823053312",
  "text" : "\u6211\u304C\u5BB6\u306E\u5EAD\u306E\u30AB\u30AD\u306E\u5B9F\u3068\u8D64\u3044\u5B9F\uFF08\u7A2E\u4E0D\u660E\uFF09\u306F\u98DF\u3079\u3064\u304F\u3055\u308C\u3001\u9CE5\u304C\u3084\u3063\u3066\u6765\u308B\u56DE\u6570\u306F\u30B0\u30F3\u3068\u6E1B\u3063\u305F\u3002\u30D2\u30E8\u30C9\u30EA\u305F\u3061\u306F\u8FD1\u6240\u306E\u304A\u5B85\u306E\u5EAD\u306E\u8D64\u3044\u5B9F\u306B\u983B\u7E41\u306B\u3084\u3063\u3066\u6765\u3066\u3044\u308B\u3002\u98DF\u3079\u5C3D\u304F\u3057\u3066\u306F\u6B21\u306E\u5834\u6240\u306B\u79FB\u52D5\u3059\u308B\u3068\u3044\u3046\u30D1\u30BF\u30FC\u30F3\u3067\u990C\u3092\u53D6\u5F97\u3057\u3066\u3044\u308B\u3088\u3046\u3060\u3002",
  "id" : 30093714823053312,
  "created_at" : "2011-01-26 02:44:35 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29161145998774272",
  "text" : "\u3044\u3064\u3082\u3068\u306F\u9006\u65B9\u5411\u306B\u5143\u8352\u5DDD\u3092\u6563\u7B56\u3002\u6797\u306E\u4E2D\u306B\u5165\u3063\u3066\u3001\u5C0F\u9CE5\u5C02\u9580\u306B\u89B3\u5BDF\u3002\u30B7\u30B8\u30E5\u30A6\u30AB\u30E9\u3001\u30E4\u30DE\u30AC\u30E9\u3001\u30B7\u30E1\u3001\u30B7\u30ED\u30CF\u30E9\u3001\u30B3\u30B2\u30E9\u3001\u30AB\u30EF\u30E9\u30D2\u30EF\u7B49\u3002\u5730\u9762\u3067\u30AC\u30B5\u30AC\u30B5\u97F3\u304C\u3059\u308B\u3068\u3001\u30B7\u30ED\u30CF\u30E9\u3084\u30A2\u30AB\u30CF\u30E9\u3092\u671F\u5F85\u3059\u308B\u304C\u30AD\u30B8\u30D0\u30C8\u3070\u304B\u308A\u304C\u76EE\u306B\u3064\u3044\u305F\u3002",
  "id" : 29161145998774272,
  "created_at" : "2011-01-23 12:58:53 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28721955360210944",
  "text" : "\u5143\u8352\u5DDD\u3067\u9CE5\u898B\u3002\u30D0\u30F3\u3001\u30BB\u30B0\u30ED\u30BB\u30AD\u30EC\u30A4\u3001\u30A4\u30AB\u30EB\u30C1\u30C9\u30EA\u3001\u30BF\u30B7\u30AE\u3001\u30B3\u30B2\u30E9\u3001\u30AA\u30CA\u30AC\u306A\u306931\u7A2E\u3002\u30D2\u30C9\u30EA\u30AC\u30E2\u304C\u4F8B\u5E74\u3088\u308A\u5C11\u306A\u3044\u3088\u3046\u306B\u611F\u3058\u308B\u3002\u5DDD\u6CBF\u3044\u306B2\u6642\u9593\u307B\u3069\u6563\u7B56\u3057\u305F\u304C\u3001\u30B5\u30AE\u985E\u3092\u4E00\u7FBD\u3082\u78BA\u8A8D\u3067\u304D\u306A\u304B\u3063\u305F\u3002\u4ECA\u65E5\u306F\u30DE\u30DF\u30C1\u30E3\u30B8\u30CA\u30A4\u306F\u898B\u308C\u306A\u304B\u3063\u305F\u3002",
  "id" : 28721955360210944,
  "created_at" : "2011-01-22 07:53:42 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27186684672081920",
  "text" : "\u81EA\u5B85\u306E\u5EAD\u306B\u30C4\u30B0\u30DF\u304C\u3088\u304F\u3084\u3063\u3066\u304F\u308B\u3002\u5730\u9762\u306B\u964D\u308A\u305F\u59FF\u3092\u4E0A\u304B\u3089\u898B\u308B\u3068\u3001\u5468\u308A\u306E\u843D\u3061\u8449\u306B\u3068\u3051\u8FBC\u3093\u3060\u304B\u306E\u3088\u3046\u306B\u3001\u898B\u4E8B\u306A\u4FDD\u8B77\u8272\u3068\u306A\u3063\u3066\u3044\u308B\u3002\u3061\u306A\u307F\u306B\u6211\u304C\u5BB6\u306E\u843D\u3061\u8449\u306F\u30AB\u30AD\u3001\u30B5\u30AF\u30E9\u3001\u30AB\u30EA\u30F3\u3002\u3046\u3061\u306B\u51FA\u5165\u308A\u3059\u308B\u30C4\u30B0\u30DF\u306F\u4F53\u8272\u304C\u8584\u3044\u3088\u3046\u306B\u611F\u3058\u3066\u3044\u308B\u3002\u82E5\u9CE5\u306E\u6E9C\u307E\u308A\u5834\u306B\u306A\u3063\u3066\u3044\u308B\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 27186684672081920,
  "created_at" : "2011-01-18 02:13:05 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26196962818654208",
  "text" : "\u5143\u8352\u5DDD\u3067\u9CE5\u898B\u3002\u8179\u90E8\u306E\u8D64\u307F\u304C\u3084\u3084\u8584\u304F\u3066\u3001\u9CF4\u304B\u306A\u3044\u30A2\u30AB\u30CF\u30E9\u3092\u767A\u898B\u3002\u5E30\u5B85\u5F8C\u3001\u56F3\u9451\u3067\u78BA\u8A8D\u3059\u308B\u3068\u30DE\u30DF\u30C1\u30E3\u30B8\u30CA\u30A4\u3060\u3063\u305F\u3002\u30DE\u30DF\u30C1\u30E3\u30B8\u30CA\u30A4\u306E\u8A9E\u6E90\u306F\uFF1F\u3002\u30AB\u30E2\u985E\u306F\u30B3\u30AC\u30E2\u3001\u30D2\u30C9\u30EA\u30AC\u30E2\u3001\u30AB\u30EB\u30AC\u30E2\u3001\u30DE\u30AC\u30E2\u3001\u30AA\u30CA\u30AC\u30AC\u30E2\u3002\u30CF\u30B7\u30D6\u30C8\u30AC\u30E9\u30B9\u306E\u6E9C\u307E\u308A\u5834\u304C\u5FA9\u6D3B\u3057\u3066\u3044\u305F\u300250\uFF5E60\u7FBD\u3050\u3089\u3044\u3002\u51AC\u5B63\u9650\u5B9A\u306E\u6E9C\u307E\u308A\u5834\u3060\u308D\u3046\u304B\u3002",
  "id" : 26196962818654208,
  "created_at" : "2011-01-15 08:40:17 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23695345879883776",
  "text" : "\u5468\u5357\u9CE5\u7D00\u884C3 \u672B\u6B66\u5DDD\u6CB3\u53E3\u3092\u53CC\u773C\u93E1\u3092\u6301\u3063\u3066\u518D\u8A2A\u3002\u30DE\u30AC\u30E2\u3001\u30DF\u30DF\u30AB\u30A4\u30C4\u30D6\u30EA\u3001\u30AB\u30F3\u30E0\u30EA\u30AB\u30A4\u30C4\u30D6\u30EA\u3001\u30BF\u30D2\u30D0\u30EA\u3001\u30A4\u30BD\u30D2\u30E8\u30C9\u30EA\u2642\u3001\u30AB\u30A4\u30C4\u30D6\u30EA\u3092\u65B0\u305F\u306B\u78BA\u8A8D\u3002\u5E30\u9014\u3001\u5E73\u7530\u5DDD\u3067\u30C0\u30A4\u30B5\u30AE\u30921\u7FBD\u78BA\u8A8D\u3002\u5634\u306F\u9EC4\u8272\u3060\u3063\u305F\u3002",
  "id" : 23695345879883776,
  "created_at" : "2011-01-08 10:59:45 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22895312418906112",
  "text" : "\u5468\u5357\u9CE5\u7D00\u884C2 \u672B\u6B66\u5DDD\u6CB3\u53E3\u3067\u30AB\u30E2\u3092\u767A\u898B\u3002\u30D2\u30C9\u30EA\u30AC\u30E2\u3001\u30CF\u30B7\u30D3\u30ED\u30AC\u30E2\u3001\u30AD\u30F3\u30AF\u30ED\u30CF\u30B8\u30ED\u3001\u30DB\u30B7\u30CF\u30B8\u30ED\u3001\u30AA\u30AB\u30E8\u30B7\u30AC\u30E2\u3001\u30AA\u30CA\u30AC\u30AC\u30E2\u3002\u4ED6\u306B\u306F\u30AB\u30EF\u30A6\u3001\u30AA\u30AA\u30D0\u30F3\u3001\u30A2\u30AA\u30B8\u3001\u30DB\u30AA\u30B8\u30ED\u3001\u30A4\u30BD\u30D2\u30E8\u30C9\u30EA\u7B49\u3002\u5C71\u53E3\u770C\u3067\u30AB\u30EF\u30A6\u3092\u898B\u305F\u306E\u306F\u306F\u521D\u3081\u3066\u3002",
  "id" : 22895312418906112,
  "created_at" : "2011-01-06 06:00:42 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22527639684124672",
  "text" : "\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u8DE1\u3067\u30EC\u30F3\u30B8\u30E3\u30AF\u306E\u3088\u3046\u306A\u9CE5\u3092\u898B\u304B\u3051\u305F\u3053\u3068\u306F\u30C4\u30A4\u30FC\u30C8\u3057\u3066\u3044\u305F\u304C\u3001\u4ECA\u5EA6\u306F\u672C\u7269\u3092\u78BA\u8A8D\u3057\u305F\u3002\u5C71\u53E3\u770C\u5468\u5357\u5E02\u3067\u30D2\u30EC\u30F3\u30B8\u30E3\u30AF\u30923\u7FBD\u78BA\u8A8D\u3057\u305F\u3002\u9996\u90FD\u570F\u306B\u306F\u7D0430\u5E74\u4F4F\u3093\u3067\u3044\u308B\u304C\u3001\u30EC\u30F3\u30B8\u30E3\u30AF\u3092\u898B\u305F\u3053\u3068\u306F\u4E00\u5EA6\u3082\u306A\u3044\u3002\u30EC\u30F3\u30B8\u30E3\u30AF\u306F\u897F\u65E5\u672C\u306E\u65B9\u304C\u591A\u3044\uFF1F\u3002\u3067\u3082\u3001\u6771\u4EAC\u306E\u4E09\u9DF9\u5E02\u306B\u306F\u9023\u96C0\u3068\u3044\u3046\u5730\u540D\u304C\u3042\u308B\u3002",
  "id" : 22527639684124672,
  "created_at" : "2011-01-05 05:39:42 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]