Grailbird.data.tweets_2010_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19985511353",
  "text" : "2010.7.31 14\u6642 \u6CB3\u539F\u306B\u305F\u3080\u308D\u3059\u308B\u5DE3\u7ACB\u3061\u5F8C\u306E\u82E5\u9CE5\u30B0\u30EB\u30FC\u30D7\u306B\u30C0\u30A4\u30B5\u30AE\u306E\u82E5\u9CE52\u7FBD\u304C\u52A0\u308F\u3063\u3066\u3044\u305F\u3002\u7E41\u6B96\u3092\u78BA\u8A8D\u3067\u304D\u305F\u30C0\u30A4\u30B5\u30AE\u306E\u5DE3\u306F2\u500B\u3002\u30B3\u30B5\u30AE\u30FB\u30C1\u30E5\u30A6\u30B5\u30AE\u3088\u308A\u3082\u5DE3\u7ACB\u3061\u306F\u9045\u3044\u3002\u30B3\u30ED\u30CB\u30FC\u5168\u4F53\u3067\u3001\u307E\u3060\u5DE3\u7ACB\u3063\u3066\u3044\u306A\u3044\u3067\u3042\u308D\u3046\u30D2\u30CA\u304C\u3044\u308B\u30B7\u30E9\u30B5\u30AE\u306E\u5DE3\u306F2\u500B\u3002\u30B3\u30ED\u30CB\u30FC\u4E0B\u306B\u30AB\u30EF\u30BB\u30DF\u304C\u3044\u305F\u3002",
  "id" : 19985511353,
  "created_at" : "2010-07-31 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19660335762",
  "text" : "2010.7.27 11\u6642 \u30B3\u30B5\u30AE\u3068\u30C1\u30E5\u30A6\u30B5\u30AE\u306E\u5DE3\u7ACB\u3061\u5F8C\u306E\u96DB\u306E\u7FA4\u308C\u304C\uFF21\u30D6\u30ED\u30C3\u30AF\u306B\u8FD1\u3044\u6728\u9670\u306B\u79FB\u3063\u3066\u3057\u307E\u3044\u3001B\u30D6\u30ED\u30C3\u30AF\u306F\u9591\u6563\u3002\u5DE3\u7ACB\u3061\u524D\u306E\u96DB\u3068\u89AA\u9CE5\u3092\u5408\u308F\u305B\u3066\u308220\u7FBD\u3082\u3044\u306A\u3044\u3002\u30B3\u30ED\u30CB\u30FC\u5168\u4F53\u3067\u3001\u5DE3\u7ACB\u3061\u524D\u306E\u30B7\u30E9\u30B5\u30AE\u306E\u96DB\u306F20\u7FBD\u5F37\u3002\u7686\u3001\u9593\u3082\u306A\u304F\u5DE3\u7ACB\u3061\u3057\u305D\u3046\u3002\u30B4\u30A4\u30B5\u30AE\u306F2\u7FBD\u3057\u304B\u78BA\u8A8D\u3067\u304D\u306A\u304B\u3063\u305F\u3002",
  "id" : 19660335762,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19660882847",
  "text" : "2010.7.27 \u8FFD\u4F38 \u3044\u3064\u3082\u306E\u89B3\u5BDF\u5730\u70B9\u304B\u3089\u5DDD\u3092\u6E21\u3063\u3066\u3001\u30B3\u30ED\u30CB\u30FC\u3092\u88CF\u5074\u304B\u3089\u89B3\u5BDF\u3057\u305F\u3002A\u30D6\u30ED\u30C3\u30AF\u306E\u88CF\u5074\u306B\u96DB\u304C5\u7FBD\u3044\u308B\u30C1\u30E5\u30A6\u30B5\u30AE\u306E\u5DE3\u304C\u3042\u3063\u305F\u3002\u524D\u5F8C\u3059\u308B\u304C\u3001\u30B3\u30ED\u30CB\u30FC\u306B\u884C\u304F\u9014\u4E2D\u3001\u6C34\u7530\u5730\u5E2F\u3067\u30B5\u30AE\u3092\u89B3\u5BDF\u3002\u30C1\u30E5\u30A6\u30B5\u30AE2\u3001\u30A2\u30AA\u30B5\u30AE1\u3002\u30B3\u30ED\u30CB\u30FC\u306E\u5317\u7D041Km\u306E\u3001\u30B3\u30ED\u30CB\u30FC\u304B\u3089\u6700\u3082\u8FD1\u3044\u6C34\u7530\u5730\u5E2F\u3002",
  "id" : 19660882847,
  "created_at" : "2010-07-27 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19550894484",
  "text" : "2010.7.26 11\u6642 \u30B4\u30A4\u30B5\u30AE\u304C\u3044\u306A\u304F\u306A\u3063\u3066\u3044\u305F\u3002\u89B3\u5BDF\u4E2D\u306B\u6570\u7FBD\u304C\u30B3\u30ED\u30CB\u30FC\u306B\u623B\u3063\u3066\u6765\u305F\u3060\u3051\u3002\u5DE3\u306B\u3068\u3069\u307E\u3063\u3066\u3044\u308B\u3082\u306E\u306F\u3044\u306A\u3044\u3002\u6700\u5F8C\u306E\u96DB\u306E\u5DE3\u7ACB\u3061\u306B\u3042\u308F\u305B\u3066\u3001\u4E00\u6589\u306B\u3069\u3053\u304B\u306B\u884C\u3063\u3066\u3057\u307E\u3063\u305F\u3088\u3046\u306A\u611F\u3058\u304C\u3059\u308B\u3002\u3053\u306E\u3068\u3053\u308D\u306E\u6691\u3055\u306B\u8CA0\u3051\u3066\u89B3\u5BDF\u3092\u6020\u3051\u305F\u3053\u3068\u304C\u6094\u3084\u307E\u308C\u308B\u3002\u53CD\u7701!\u3002",
  "id" : 19550894484,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19551301417",
  "text" : "2010.7.26 \u8FFD\u4F38 \u30B3\u30B5\u30AE\u306E\u96DB\u306E\u811A\u306F\u8584\u3044\u9EC4\u7DD1\u3002\u53E3\u306E\u4E2D\u306F\u8D64\u3044\u3002\u7FBD\u88CF\u306F\u30C1\u30E5\u30A6\u30B5\u30AE\u306E\u3088\u3046\u306B\u30D4\u30F3\u30AF\u3067\u306F\u306A\u304F\u767D\u3002\u5DE3\u304B\u3089\u51FA\u3066\u3001\u5DDD\u9762\u306B\u7A81\u304D\u51FA\u305F\u5C0F\u679D\u306B\u6B62\u307E\u308A\u3001\u6C34\u3092\u98F2\u3080\u96DB\u304C\u3044\u305F\u3002\u30B3\u30ED\u30CB\u30FC\u76F4\u524D\u3067\u30AB\u30EF\u30A6\u304C\uFF11\u7FBD\u6CF3\u3044\u3067\u3044\u305F\u3002\u30CF\u30B7\u30D6\u30C8\u30AC\u30E9\u30B9\u304C\uFF11\u7FBD\u3001\u30B3\u30ED\u30CB\u30FC\u306B\u4FB5\u5165\u3057\u3001\u67AF\u308C\u8349\u306E\u3088\u3046\u306A\u3082\u306E\u3092\u304F\u308F\u3048\u3066\u884C\u3063\u305F\u3002",
  "id" : 19551301417,
  "created_at" : "2010-07-26 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19076094686",
  "text" : "2010.7.21 17\u6642 \u30C0\u30A4\u30B5\u30AE\u306E\u5DE3\u3068\u96DB\u3092\u78BA\u8A8D\u3067\u304D\u305F\u3002B\u30D6\u30ED\u30C3\u30AF\u3067\u306F\u30B7\u30E9\u30B5\u30AE\u306E\u96DB20\u7FBD\u3050\u3089\u3044\u304C\u5DE3\u306E\u3042\u3063\u305F\u6728\u3005\u306E\u4E0B\u304B\u3089\u6CB3\u539F\u306B\u7E70\u308A\u51FA\u3057\u3066\u3044\u305F\u3002\u96DB\u304C\u5B75\u3089\u306A\u3044\u30B4\u30A4\u30B5\u30AE\u306E\u5DE3\u306B\u89AA\u9CE5\u306E\u59FF\u306F\u306A\u304B\u3063\u305F\u3002A\u30D6\u30ED\u30C3\u30AF\u306B\u982D\u3068\u9996\u306E\u305D\u308C\u305E\u308C\u3054\u304F\u4E00\u90E8\u3060\u3051\u304C\u4E9C\u9EBB\u8272\u306E\u30A2\u30DE\u30B5\u30AE\u304C\u3044\u305F\u30022\u5E74\u76EE\u306E\u82E5\u9CE5\u306A\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 19076094686,
  "created_at" : "2010-07-21 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18888789108",
  "text" : "2010.7.19 10\u6642\u534A \u5409\u5DDD\u5E02\u306E\u4E2D\u5DDD\u6CB3\u539F\u306B\u3042\u308B\u30B3\u30ED\u30CB\u30FC\u307E\u3067\u51FA\u304B\u3051\u305F\u3002\u3053\u3061\u3089\u306E\u65B9\u304C\u898F\u6A21\u304C\u5927\u304D\u3044\u3002\u30B7\u30E9\u30B5\u30AE\u3060\u3051\u3067200\u7FBD\u3092\u8D85\u3048\u3066\u3044\u308B\u3002\u4ECA\u5E74\u5DE3\u7ACB\u3063\u305F\u3082\u306E\u3082\u542B\u3081\u3066\u3001\u30B7\u30E9\u30B5\u30AE260\u3001\u30B4\u30A4\u30B5\u30AE30\u3068\u898B\u7A4D\u3082\u3063\u305F\u3002\u30A2\u30AA\u30B5\u30AE\u306E\u96DB\uFF08\u3059\u3067\u306B\u304B\u306A\u308A\u5927\u304D\u3044\uFF09\u304C1\u7FBD\u3001\u30A2\u30DE\u30B5\u30AE\u30821\u7FBD\u3044\u305F\u3002",
  "id" : 18888789108,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18889165014",
  "text" : "2010.7.19 \u8FFD\u4F38 \u5143\u8352\u5DDD\u3068\u6BD4\u3079\u3066\u96DB\u306E\u5DE3\u7ACB\u3061\u304C\u65E9\u3044\u3068\u611F\u3058\u305F\u3002\u5DE3\u306E\u4E2D\u3067\u89AA\u9CE5\u306E\u5E30\u308A\u3092\u5F85\u3063\u3066\u3044\u308B\u3088\u3046\u306A\u5C0F\u3055\u3044\u96DB\u306F\u4E00\u7FBD\u3082\u3044\u306A\u304B\u3063\u305F\u3002\u6210\u9CE5\u4E26\u306E\u5927\u304D\u3055\u306B\u306A\u3063\u305F\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u304C5,6\u7FBD\u76EE\u306B\u3064\u3044\u305F\u7A0B\u5EA6\u3002\u307E\u305F\u3001\u30C0\u30A4\u30B5\u30AE\u306E\u6BD4\u7387\u304C\u9AD8\u3044\u3002\u5DDD\u306E\u672C\u6D41\u306B\u652F\u6D41\u304C\u5408\u6D41\u3059\u308B\u5730\u70B9\u306B\u3042\u308B\u3068\u3044\u3046\u7ACB\u5730\u6761\u4EF6\u306F\u540C\u3058\u3002",
  "id" : 18889165014,
  "created_at" : "2010-07-19 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18826059513",
  "text" : "2010.7.18 16\u6642 \u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u306F\u3059\u3067\u306B\u30B3\u30ED\u30CB\u30FC\u306E\u5916\u306B\u98DB\u3093\u3067\u51FA\u304B\u3051\u3066\u3044\u308B\u3002\uFF22\u30D6\u30ED\u30C3\u30AF\u306E\u96DB\u304C\u5B75\u3089\u306A\u3044\u30B4\u30A4\u30B5\u30AE\u306E\u5DE3\u3067\u306F\u89AA\u9CE5\u304C\u4ECA\u65E5\u3082\u62B1\u5375\u30DD\u30FC\u30BA\u3002A\u30D6\u30ED\u30C3\u30AF\u306E\u96DB\u304C\u5B75\u3089\u306A\u3044\u3068\u601D\u308F\u308C\u3066\u3044\u305F\u30B7\u30E9\u30B5\u30AE\u306E\u5DE3\uFF12\u3064\u3067\u5171\u306B\u96DB\u3092\u78BA\u8A8D\u3002\u80B2\u3063\u305F\u96DB\u3092\u89AA\u9CE5\u3068\u52D8\u9055\u3044\u3057\u3066\u3044\u305F\u3002\u89AA\u5B50\u63C3\u3063\u3066\u3044\u308B\u3068\u3053\u308D\u3092\u898B\u3066\u7D0D\u5F97\u3002",
  "id" : 18826059513,
  "created_at" : "2010-07-18 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18766909343",
  "text" : "2010.7.17 16\u6642\u534A \u30B3\u30ED\u30CB\u30FC\u304B\u3089\u6771\u5317\u306B\u7D041.5Km\u306E\u6C34\u7530\u5730\u5E2F\u306B\u9060\u5F81\u3057\u305F\u3002\u30B3\u30B5\u30AE\u3001\u30C1\u30E5\u30A6\u30B5\u30AE\u3001\u30B4\u30A4\u30B5\u30AE\u304C1,2\u7FBD\u305A\u3064\u898B\u53D7\u3051\u3089\u308C\u305F\u3002\u304A\u305D\u3089\u304F\u3001\u3042\u306E\u30B3\u30ED\u30CB\u30FC\u306E\u201D\u4F4F\u4EBA\u201D\u3067\u3042\u308D\u3046\u304C\u3001\u78BA\u8A8D\u3059\u308B\u3059\u3079\u304C\u306A\u3044\u3002\u3042\u3061\u3053\u3061\u3067\u30BB\u30C3\u30AB\u304C\u9CF4\u3044\u3066\u3044\u305F\u3002\u30E0\u30AF\u30C9\u30EA\u304C100\u7FBD\u3050\u3089\u3044\u7FA4\u308C\u3066\u3044\u305F\u3002",
  "id" : 18766909343,
  "created_at" : "2010-07-17 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18663117721",
  "text" : "2010.716 14\u6642 \u5DE3\u7ACB\u3061\u9593\u3082\u306A\u3044\u30B4\u30A4\u30B5\u30AE\u304C\u30E8\u30BF\u30E8\u30BF\u3068\u98DB\u3093\u3067\u3044\u305F\u3002A\u30D6\u30ED\u30C3\u30AF\u3067\u96DB\u306E\u3044\u308B\u30B7\u30E9\u30B5\u30AE\u306E\u5DE3\u306F8,9\u500B\u3002B\u30D6\u30ED\u30C3\u30AF\u306F\u5730\u9762\u304C\u30B7\u30E9\u30B5\u30AE\u306E\u96DB\u3060\u3089\u3051\u3002\u7FBD\u3070\u305F\u304D\u306E\u7DF4\u7FD2\u3092\u3059\u308B\u3082\u306E\u3001\u5C0F\u3057\u98DB\u3073\u3042\u304C\u308C\u308B\u3082\u306E\u306A\u3069\u3001\u5927\u6DF7\u96D1\u72B6\u614B\u3002\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u304C\u5B75\u3089\u306A\u3044\u5DE3\u304C\u4E00\u3064\u3002\u89AA\u9CE5\u306F\u62B1\u5375\u3057\u3066\u3044\u308B\u3002",
  "id" : 18663117721,
  "created_at" : "2010-07-16 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18515665197",
  "text" : "2010.7.14 18\u6642\u534A \u89AA\u9CE5\u3060\u3051\u3092\u30AB\u30A6\u30F3\u30C8\u3057\u3066\u30B7\u30E9\u30C0\u30AE\u306F\u7D0490\u7FBD\u3002\u811A\u5148\u304C\u9EC4\u8272\u3067\u306F\u306A\u304F\u8D64\u306B\u8FD1\u3044\u3088\u3046\u306A\u30B3\u30B5\u30AE\u304C\u3044\u305F\u3002A\u30D6\u30ED\u30C3\u30AF\u3067\u96DB\u306E\u3044\u308B\u30B7\u30E9\u30B5\u30AE\u306E\u5DE3\u306F5,6\u500B\u3002\u4E00\u756A\u76EE\u7ACB\u3064\u4F4D\u7F6E\u306B\u3044\u305F\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u304C\u98DB\u3093\u3067\u5DE3\u306B\u623B\u3063\u3066\u6765\u305F\u306E\u3092\u78BA\u8A8D\u3057\u305F\u3002\u9CE5\u898B\u306E\u5973\u6027\u306B\u53CC\u773C\u93E1\u3092\u8CB8\u3057\u3066\u3042\u3052\u305F\u3002\u89AA\u5207\uFF1F\u8FF7\u60D1\uFF1F\u3002",
  "id" : 18515665197,
  "created_at" : "2010-07-14 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18347986676",
  "text" : "2010.7.12 15\u6642\u534A \u30B3\u30ED\u30CB\u30FC\u3067\u306F\u306A\u304F\u3001\u89AA\u9CE5\u306E\u990C\u5834\u3068\u601D\u308F\u308C\u308B\u8ABF\u6574\u6C60\u306B\u884C\u3063\u3066\u307F\u305F\u3002\u30C0\u30A4\u30B5\u30AE1\u3001\u30C1\u30E5\u30A6\u30B5\u30AE2\u3001\u30B3\u30B5\u30AE4\u30015\u7FBD\u3002\u30A2\u30AA\u30B5\u30AE\u30824\u7FBD\u3002\u51852\u7FBD\u306F\u3084\u3051\u306B\u7070\u8272\u3063\u307D\u3044\u3002\u5DE3\u7ACB\u3061\u9593\u3082\u306A\u3044\u306E\u3060\u308D\u3046\u304B\u3002\u3053\u3053\u306F\u30B3\u30ED\u30CB\u30FC\u304B\u3089\u5317\u306B3Km\u3050\u3089\u3044\u3002\u30B5\u30AE\u304C\u3088\u304F\u96C6\u307E\u308B\u5730\u70B9\u3092\u9806\u756A\u306B\u8A2A\u308C\u3066\u307F\u3088\u3046\u3002",
  "id" : 18347986676,
  "created_at" : "2010-07-12 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18190880700",
  "text" : "2010.7.10 16\u6642\u534A \u30C0\u30A4\u30B5\u30AE\u30921\u7FBD\u78BA\u8A8D\u3057\u305F\u304C\u3001\u30C0\u30A4\u30B5\u30AE\u306E\u30D2\u30CA\u306F\u78BA\u8A8D\u3067\u304D\u306A\u3044\u3002\u4ECA\u3067\u3082\u62B1\u5375\u4F53\u5236\u306E\u89AA\u9CE5\u306E\u5375\u306F\u3082\u3046\u5B75\u3089\u306A\u3044\u306E\u3060\u308D\u3046\u304B\u3002\u30B3\u30ED\u30CB\u30FC\u624B\u524D\u306E\u5DDD\u3092\u30AB\u30CC\u30FC\uFF08\u30AB\u30E4\u30C3\u30AF\uFF1F\uFF09\u3092\u6F15\u3044\u3067\u9061\u3063\u3066\u3044\u308B\u5909\u306A\u4EBA\u304C\u3044\u305F\u3002\u3057\u304B\u3057\u3001\u30B5\u30AE\u3092\u898B\u3066\u3044\u308B\u4EBA\u3068\u30AB\u30CC\u30FC\u3092\u6F15\u3050\u4EBA\u3001\u3069\u3061\u3089\u304C\u3088\u308A\u5909\u306A\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 18190880700,
  "created_at" : "2010-07-10 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18191215169",
  "text" : "2010.7.10 \u3055\u3044\u305F\u307E\u5E02\u91CE\u7530\u307E\u3067\u81EA\u8EE2\u8ECA\u3067\u51FA\u304B\u3051\u305F\u3002\u30B5\u30AE\u5C71\u8A18\u5FF5\u9928\u3067\u662D\u548C30\u5E74\u4EE3\u306E\u91CE\u7530\u306E\u30B5\u30AE\u5C71\u306E\u98A8\u666F\u306A\u3069\u306E\u5199\u771F\u3092\u898B\u305F\u3002\u30B5\u30AE\u306E\u591A\u3055\u306B\u3073\u3063\u304F\u308A\u3002\u4ECA\u3001\u79C1\u304C\u89B3\u5BDF\u3057\u3066\u3044\u308B\u30B3\u30ED\u30CB\u30FC\u306A\u3069\u3082\u306E\u306E\u6570\u3067\u306F\u306A\u3044\u3002\u5DE3\u306E\u6570\u304C6000\u500B\u3001\u898B\u7269\u4EBA\u7528\u306E\u5854\u307E\u3067\u3042\u3063\u305F\u3068\u3044\u3046\u306E\u3060\u304B\u3089\u3001\u3059\u3054\u904E\u304E\u308B\u3002",
  "id" : 18191215169,
  "created_at" : "2010-07-10 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18096274746",
  "text" : "2010.7.9 14\u6642 A\u30D6\u30ED\u30C3\u30AF\u306F\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u7D0430\u7FBD\u3001\u30B7\u30E9\u30B5\u30AE\u306F\u7D0410\u7FBD\u3002\u89AA\u9CE5\u304C\u62B1\u5375\u4F53\u5236\u3067\u96DB\u306E\u6C17\u914D\u306E\u306A\u3044\u5DE3\u306F\u30B7\u30E9\u30B5\u30AE3\u3002\u30B4\u30A4\u30B5\u30AE0\u3002\u4E00\u756A\u76EE\u7ACB\u3064\u7B87\u6240\u306B\u3044\u308B4\u7FBD\u306F\u540C\u3058\u89AA\u9CE5\u306B\u53CD\u5FDC\u3057\u3066\u3044\u305F\u3002\u3084\u306F\u308A\u30011\u3064\u306E\u5DE3\u3067\u80B2\u3063\u305F\u3088\u3046\u3060\u3002\u30AF\u30C1\u30D0\u30B7\u306E\u9EC4\u8272\u304C\u9BAE\u3084\u304B\u306A\u30A2\u30DE\u30B5\u30AE\u3089\u3057\u304D\u500B\u4F53\u304C1\u7FBD\u3044\u305F\u3002",
  "id" : 18096274746,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18096612662",
  "text" : "2010.7.9 \u8FFD\u4F38 B\u30D6\u30ED\u30C3\u30AF\u306F\u30B7\u30E9\u30B5\u30AE\u306E\u96DB\u7D0420\u7FBD\u3001\u65E2\u306B\u5DE3\u7ACB\u3063\u305F\u3089\u3057\u30446,7\u7FBD\u306F\u5730\u9762\u306B\u304A\u308A\u305F\u308A\u3001\u4F4E\u3044\u679D\u306B\u98DB\u3073\u4E0A\u304C\u3063\u305F\u308A\u3057\u3066\u3044\u308B\u3002\u96DB\u306E\u7FBD\u88CF\u306F\u30D4\u30F3\u30AF\u2192\u7070\u8272\u2192\u767D\u3068\u5909\u5316\u3059\u308B\u3088\u3046\u3060\u3002\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u306F6,7\u7FBD\u3002\u5C0F\u3055\u3044\u3082\u306E\u3082\u3044\u308B\u3002\u89AA\u9CE5\u304C\u62B1\u5375\u4F53\u5236\u3067\u96DB\u306E\u6C17\u914D\u304C\u306A\u3044\u5DE3\u306F\u30B7\u30E9\u30B5\u30AE2\u3001\u30B4\u30A4\u30B5\u30AE1\u3002",
  "id" : 18096612662,
  "created_at" : "2010-07-09 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17936268702",
  "text" : "2010.7.7 14\u6642\u534A A\u30D6\u30ED\u30C3\u30AF\u306F\u4ECA\u5E74\u751F\u307E\u308C\u306E\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u304C10\u7FBD\u4EE5\u4E0A\u3002\u5DE3\u7ACB\u3061\u5F8C\u306A\u306E\u304B\u3069\u3046\u304B\u306F\u5206\u304B\u3089\u306A\u3044\u304B\u304C\u3001\u6728\u3005\u306E\u3066\u3063\u307A\u3093\u4ED8\u8FD1\u306B\u591A\u304F\u3044\u308B\u3002\u4E00\u756A\u76EE\u7ACB\u3063\u3066\u3044\u305F2\u7FBD\u306E\u96DB\u3068\u305D\u306E\u3059\u3050\u4E0B\u306B\u3044\u305F2\u7FBD\u306F\u540C\u3058\u5DE3\u3060\u3063\u305F\u306E\u304B\u3082\u77E5\u308C\u306A\u3044\u3002\u4E00\u7FBD\u306E\u89AA\u9CE5\u304C\u623B\u3063\u3066\u6765\u305F\u6642\u30014\u7FBD\u304C\u4E00\u6589\u306B\u30A8\u30B5\u3092\u306D\u3060\u3063\u3066\u3044\u305F\u3002",
  "id" : 17936268702,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17936413585",
  "text" : "2010.7.7 \u8FFD\u4F38 B\u30D6\u30ED\u30C3\u30AF\u306F\u30B7\u30E9\u30B5\u30AE\u306E\u30D2\u30CA\u304C10\u7FBD\u4EE5\u4E0A\u3002\u7FBD\u306E\u88CF\u304C\u30D4\u30F3\u30AF\u8272\u306E\u500B\u4F53\u306F\u78BA\u8A8D\u3067\u304D\u306A\u304B\u3063\u305F\u3002A\u30D6\u30ED\u30C3\u30AF\u306B\u6BD4\u3079\u3001\u307E\u3060\u5C0F\u3055\u3044\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u304C2\u7FBD\u3002\u4ECA\u3067\u3082\u62B1\u5375\u4F53\u5236\u306E\u30B7\u30E9\u30B5\u30AE\u304C5\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE\u304C1\u7FBD\u3002\u3053\u308C\u304B\u3089\u3001\u5B75\u5316\u3059\u308B\u306E\u3060\u308D\u3046\u304B\u3002\u6642\u6298\u3001\u30AA\u30AA\u30E8\u30B7\u30AD\u30EA\u306E\u58F0\u3082\u805E\u3053\u3048\u305F\u3002",
  "id" : 17936413585,
  "created_at" : "2010-07-07 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17628248390",
  "text" : "2010.7.3 11\u6642 \u4E00\u9031\u9593\u632F\u308A\u306B\u89B3\u5BDF\u3002\u30B4\u30A4\u30B5\u30AE\u306E\u30D2\u30CA\u306F\u65E2\u306B\u4F55\u7FBD\u304B\u5DE3\u7ACB\u3063\u305F\u6A21\u69D8\u3002\u5DE3\u7ACB\u3063\u3066\u3044\u306A\u3044\u3082\u306E\u3082\u30DB\u30B7\u30B4\u30A4\u3068\u547C\u3093\u3067\u5DEE\u3057\u652F\u3048\u306A\u3044\u72B6\u614B\u3002\u30C1\u30E5\u30A6\u30B5\u30AE\u306E\u30D2\u30CA\u3082\u6025\u6210\u9577\u3002\u7FBD\u3070\u305F\u304D\u3092\u7E70\u308A\u8FD4\u3057\u3066\u3044\u308B\u3002\u7FBD\u88CF\u306F\u3084\u306F\u308A\u30D4\u30F3\u30AF\u8272\u3002\u30D2\u30CA\u304C\u5927\u304D\u304F\u306A\u308A\u3001\u89AA\u9CE5\u3060\u3051\u306E\u30AB\u30A6\u30F3\u30C8\u306F\u56F0\u96E3\u306B\u306A\u3063\u3066\u304D\u305F\u3002",
  "id" : 17628248390,
  "created_at" : "2010-07-03 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]