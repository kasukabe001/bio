Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64848850149572608",
  "text" : "\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u304C\u306A\u304F\u306A\u3063\u305F\u7406\u7531\u304C\u5206\u304B\u308A\u307E\u3057\u305F\u3002\u5730\u4E3B\u3055\u3093\u304C\u30B3\u30ED\u30CB\u30FC\u3092\u5ACC\u3063\u3066\u3001\u30D6\u30EB\u30C9\u30FC\u30B6\u30FC\u3067\u6574\u5730\u3057\u305F\u3068\u306E\u3053\u3068\u3002\u30B5\u30AE\u306E\u3044\u306A\u3044\u6642\u671F\u306B\u4F5C\u696D\u3092\u884C\u3046\u5206\u3001\u826F\u5FC3\u7684\u3068\u8A00\u3048\u308B\u306E\u304B\u3082\u77E5\u308C\u306A\u3044\u304C\u3001\u3053\u3046\u306A\u308B\u524D\u306B\u4F55\u3068\u304B\u3057\u305F\u304B\u3063\u305F\u3002",
  "id" : 64848850149572608,
  "created_at" : "2011-05-02 00:29:05 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]