Grailbird.data.tweets_2010_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8349792410",
  "text" : "2010.1.29 \u30E2\u30BA1(\u91CE\u9CE5\u306E\u68EE\u306E\u7AEF\u3001\u7551\u3068\u306E\u5883\u754C\u3042\u305F\u308A)\u3001\u30B3\u30AC\u30E24 or 5(\u65E7\u53E4\u9685\u7530\u5DDD)",
  "id" : 8349792410,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8313142283",
  "text" : "2010.1.28 \u30B7\u30E11(\u3044\u3064\u3082\u306E\u6CBC)",
  "id" : 8313142283,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8267314164",
  "text" : "2010.1.27 \u30AA\u30CA\u30AC1\u7FBD\u3067\u9CF4\u304D\u9A12\u3050(\u91CE\u9CE5\u306E\u68EE)\u3001\u30B3\u30AC\u30E25\u3001\u30BF\u30B7\u30AE1(\u65E7\u53E4\u9685\u7530\u5DDD)",
  "id" : 8267314164,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8053639836",
  "text" : "20010.1.22 \u30B7\u30E1\uFF08\u3044\u3064\u3082\u306E\u6CBC\uFF09\u3001\u30B7\u30B8\u30E5\u30A6\u30AB\u30E92\uFF08\u91CE\u9CE5\u306E\u68EE\uFF09",
  "id" : 8053639836,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8012627260",
  "text" : "2010.1.21 \u3044\u3064\u3082\u306E\u6CBC\u306E\u6C37\u306A\u304F\u306A\u308B\u3002\u30B7\u30E1\uFF11\u9053\u8DEF\u306E\u30A2\u30B9\u30D5\u30A1\u30EB\u30C8\u306E\u4E0A\u306B\u964D\u308A\u3066\u3044\u305F\u3002\u30B7\u30ED\u30CF\u30E91\u7530\u3093\u307C\u3067\u3002\u30AB\u30EF\u30E9\u30D2\u30EF1\u3001\u30C4\u30B0\u30DF\uFF11\uFF0E",
  "id" : 8012627260,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7808220621",
  "text" : "2010.1.16 \u3044\u3064\u3082\u306E\u6CBC\u5B8C\u5168\u7D50\u6C37 \u30B3\u30B2\u30E91(\u91CE\u9CE5\u306E\u68EE)",
  "id" : 7808220621,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7771068669",
  "text" : "2010.1.15\u30B7\u30E1\uFF11 \u3044\u3064\u3082\u306E\u6CBC",
  "id" : 7771068669,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7737676120",
  "text" : "2010.1.14 \u5CA9\u69FB\u533A\u5357\u5E73\u91CE\u304B\u3089\u306E\u5E30\u308A\u9053\u3001\u30B8\u30E7\u30A6\u30D3\u30BF\u30AD\u26421",
  "id" : 7737676120,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7424051883",
  "text" : "2010.1.6 \u30CF\u30AF\u30BB\u30AD\u30EC\u30A42\u3001\u30C0\u30A4\u30B5\u30AE\u3001\u30B3\u30B5\u30AE\u3001\u30AB\u30EB\u30AC\u30E22\uFF08\u65E7\u53E4\u9685\u7530\u5DDD)",
  "id" : 7424051883,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7428920694",
  "text" : "2010.1.6\u663C \u30B7\u30ED\u30CF\u30E92,\u30B7\u30B8\u30E5\u30A6\u30AB\u30E9(\u516B\u5E61\u516C\u5712)",
  "id" : 7428920694,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7396031589",
  "text" : "2010.1.5 \u3044\u3064\u3082\u306E\u6CBC\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\uFF11\u3001\u30AB\u30EB\u30AC\u30E2\uFF11",
  "id" : 7396031589,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7331661605",
  "text" : "2010.1.3 \u65E7\u53E4\u9685\u7530\u5DDD \u30B8\u30E7\u30A6\u30D3\u30BF\u30AD\u26401,\u3044\u3064\u3082\u306E\u6CBC\u3001\u534A\u5206\u4F4D\u7D50\u6C37",
  "id" : 7331661605,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7347728509",
  "text" : "2010.1.4 \u30B8\u30E7\u30A6\u30D3\u30BF\u30AD\u26401\u3001\u30C4\u30B0\u30DF1(\u5357\u4E2D\u66FD\u6839)\u3001\u30C0\u30A4\u30B5\u30AE1(\u65E7\u53E4\u9685\u7530\u5DDD)",
  "id" : 7347728509,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7267611478",
  "text" : "2010.1.1\u3000\u30CE\u30B9\u30EA1\u3001\u30A2\u30AA\u30B82\uFF08\u5FB3\u529B\uFF09\u3001\u30B7\u30ED\u30CF\u30E93\uFF08\u3044\u3064\u3082\u306E\u6C60\uFF09",
  "id" : 7267611478,
  "created_at" : "2010-01-01 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]