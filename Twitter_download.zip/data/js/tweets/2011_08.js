Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102540655993176064",
  "text" : "7\u6708\u672B\u304B\u3089\u30C1\u30E5\u30A6\u30B5\u30AE\u3082\u6628\u5E74\u3068\u540C\u3058\u5834\u6240\u3067\u3088\u304F\u307F\u304B\u3051\u308B\u3002\u5852\u306A\u306E\u304B\u990C\u5834\u306A\u306E\u304B\u3088\u304F\u5206\u304B\u3089\u306A\u3044\u3002\u30B3\u30B5\u30AE\u3001\u30C0\u30A4\u30B5\u30AE\u306F\u898B\u304B\u3051\u306A\u3044\u3002",
  "id" : 102540655993176064,
  "created_at" : "2011-08-14 00:42:52 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102436766631473153",
  "text" : "8\u6708\u306E\u521D\u3081\u9803\u304B\u3089\u3001\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u304C\u6628\u5E74\u3068\u540C\u3058\u6728\u3092\u30CD\u30B0\u30E9\u3068\u3057\u3066\u5229\u7528\u3057\u3066\u3044\u308B\u3002",
  "id" : 102436766631473153,
  "created_at" : "2011-08-13 17:50:03 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "torimidasi",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102435412009684992",
  "text" : "2011.8.7 \u81EA\u5B85\u306E\u5EAD\u6728\u3092\u526A\u5B9A\u4E2D\u306B\u805E\u304D\u306A\u308C\u306C\u9CE5\u306E\u9CF4\u304D\u58F0\u304C\u3002\u58F0\u306E\u3059\u308B\u65B9\u3092\u898B\u308B\u3068\u3001\u731B\u79BD\u985E1\u7FBD\u304C\u4E0A\u7A7A\u3092\u304F\u308B\u304F\u308B\u3068\u65CB\u56DE\u4E2D\u3002\u59FF\u306F\u30BF\u30AB\u3067\u3001\u30C8\u30D3\u306E\u9CF4\u304D\u58F0\u3068\u306F\u9055\u3046\u3002\u3067\u3082\u3001\u9996\u304C\u7D30\u304F\u3066\u4F55\u3068\u306A\u304F\u30A2\u30AA\u30B5\u30AE\u306E\u3088\u3046\u306B\u3082\u601D\u3048\u308B\u898B\u6163\u308C\u306C\u9CE5\u3060\u3002\u3053\u306E\u9CE5\u306E\u6B63\u4F53\u306F\u30CF\u30C1\u30AF\u30DE\u3067\u3057\u305F\u3002#torimidasi",
  "id" : 102435412009684992,
  "created_at" : "2011-08-13 17:44:40 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]