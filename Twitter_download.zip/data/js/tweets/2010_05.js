Grailbird.data.tweets_2010_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15028270605",
  "text" : "2010.5.30 16\u6642\u9803 \u30B7\u30E9\u30B5\u30AE\u306F100\u7FBD\u3092\u30AB\u30A6\u30F3\u30C8\u3001\u30B4\u30A4\u30B5\u30AE\u306F\u7D0425\u7FBD\u3002\u30D2\u30CA\u306E\u58F0\u306F\u805E\u3053\u3048\u306A\u3044\u3002\u5634\u306E\u9EC4\u8272\u3044\u30C0\u30A4\u30B5\u30AE\u30924\u7FBD\u78BA\u8A8D(\u6628\u65E5\u306E\u306F\u76EE\u306E\u5468\u308A\u304C\u7DD1\uFF09\u3002\u30C0\u30A4\u30B5\u30AE\u306F\u3084\u306F\u308A\u76EE\u7ACB\u3064\u3002\u30B4\u30A4\u30B5\u30AE\u304C\u6728\u304B\u3089\u964D\u308A\u3066\u3001\u5CB8\u8FBA\u306E\u6C34\u969B\u306B7,8\u7FBD\u3002\u4F11\u65E5\u306E\u305B\u3044\u304B\u3001\u4ECA\u65E5\u3082\u9CE5\u898B\u5BA2\u304C\u3061\u3089\u307B\u3089\u3002",
  "id" : 15028270605,
  "created_at" : "2010-05-30 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14959971428",
  "text" : "2010.5.29 11\u6642\u9803\u3000\u5DDD\u3092\u6E21\u3063\u3066\u30B3\u30ED\u30CB\u30FC\u306E\u53CD\u5BFE\u5074\u304B\u3089\u3082\u89B3\u5BDF\u3002\u30B7\u30E9\u30B5\u30AE\u306F100\u3050\u3089\u3044\u3001\u30B4\u30A4\u30B5\u30AE\u306F40\u3050\u3089\u3044\u3068\u898B\u7A4D\u3082\u3063\u305F\u3002\u30C0\u30A4\u30B5\u30AE\u306F\uFF14,5\u7FBD\u3068\u6570\u306F\u5C11\u306A\u3044\u304C\u76EE\u7ACB\u3064\u4F4D\u7F6E\u306B\u55B6\u5DE3\u3002\u30C1\u30E5\u30A6\u30B5\u30AE\u3068\u30B3\u30B5\u30AE\u306F\u307B\u307C\u540C\u6570\u3002\u30D2\u30CA\u306E\u9CF4\u58F0\u306F\u805E\u3053\u3048\u306A\u3044\u3002\u4E00\u822C\u306E\u9CE5\u898B\u5BA2\u304C\u76EE\u306B\u3064\u304F\u3088\u3046\u306B\u306A\u3063\u3066\u304D\u305F\u3002",
  "id" : 14959971428,
  "created_at" : "2010-05-29 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14881802736",
  "text" : "2010.5.28 \u5348\u524D11\u6642\u3000\u30B7\u30E9\u30B5\u30AE\u7D0485\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE\u7D0425\u7FBD\u3002\u30B7\u30E9\u30B5\u30AE\u306F\u304B\u3089\u3060\u3092\u6A2A\u306B\u3057\u3066\u6B62\u307E\u3063\u3066\u3044\u308B\u3082\u306E\u304C\u3059\u3044\u3076\u3093\u591A\u304F\u306A\u3063\u305F\u3002\u534A\u6570\u8FD1\u304F\u304C\u62B1\u5375\u30DD\u30FC\u30BA\u3060\u3002\u30B4\u30A4\u30B5\u30AE\u3082\u62B1\u5375\u30DD\u30FC\u30BA\u304C\u4F55\u7FBD\u304B\u76EE\u306B\u3064\u3044\u305F\u3002\u30AB\u30EF\u30A6\u304C\u4E00\u7FBD\u4E0A\u7A7A\u3092\u901A\u904E\u3057\u305F\u304C\u3001\u964D\u308A\u3066\u306F\u6765\u306A\u304B\u3063\u305F\u3002",
  "id" : 14881802736,
  "created_at" : "2010-05-28 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14677976171",
  "text" : "2010.5.24 14:20\u9803 \u30B7\u30E9\u30B5\u30AE70\u7FBD\u5F37\u3001\u30B4\u30A4\u30B5\u30AE20\u7FBD\u5F31\u3002\u30B4\u30A4\u30B5\u30AE\u306F\u30DB\u30B7\u30B4\u30A4\u3068\u534A\u3005\u3050\u3089\u3044\u3002\u62B1\u5375\u30DD\u30FC\u30BA\u306E\u30B4\u30A4\u30B5\u30AE\u30821\uFF642\u7FBD\u3002\u5927\u4E2D\u5C0F\u306E\u6BD4\u7387\u306F1:3:3\u3050\u3089\u3044\u3067\u3001\u4E2D\u304C\u5C11\u3057\u5C0F\u3088\u308A\u3082\u591A\u3044\u3002",
  "id" : 14677976171,
  "created_at" : "2010-05-25 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14489894247",
  "text" : "2010.5.22 14\u6642\u9803 \u30B7\u30E9\u30B5\u30AE\u7D0470\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE\u7D0420\u7FBD\u3002\u30B7\u30E9\u30B5\u30AE\u306F\u62B1\u5375\u30DD\u30FC\u30BA\u306E\u3082\u306E\u304C7,8\u7FBD\u3050\u3089\u3044\u3002\u30B4\u30A4\u30B5\u30AE\u306F\u62B1\u5375\u30DD\u30FC\u30BA\u306E\u3082\u306E\u306F\u3044\u306A\u3044\u3002\u5927\u4E2D\u5C0F\u306E\u6BD4\u7387\u306F1:4:2\u3050\u3089\u3044\u3060\u308D\u3046\u304B\u3002\u30A2\u30DE\u30B5\u30AE\u3001\u30A2\u30AA\u30B5\u30AE\u3001\u30AB\u30EF\u30A6\u306F\u3044\u306A\u3044\u3002",
  "id" : 14489894247,
  "created_at" : "2010-05-22 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14406597378",
  "text" : "2010.5.21 \u30B7\u30E9\u30B5\u30AE\u7D0460\u7FBD\u3001\u5927\u4E2D\u5C0F\u305D\u308C\u305E\u308C\u78BA\u8A8D\u3002\u30C1\u30E5\u30A6\u30B5\u30AE\u304C\u4E00\u756A\u591A\u3044\u3088\u3046\u306B\u611F\u3058\u308B\u3002\u76EE\u306E\u5468\u308A\u304C\u8584\u7DD1\u306E\u30C0\u30A4\u30B5\u30AE\u306E\u3082\u3044\u305F\u30024,5\u7FBD\u304C\u304B\u3089\u3060\u3092\u6A2A\u306B\u3057\u3066\u3058\u3063\u3068\u6B62\u307E\u3063\u3066\u3044\u305F\u3002\u62B1\u5375\u4E2D\uFF1F\u3002\u30B4\u30A4\u30B5\u30AE\u306F\u7D0425\u7FBD\u3002\u3053\u3061\u3089\u306F\u3001\u62B1\u5375\u3092\u7591\u308F\u308C\u308B\u3082\u306E\u306F\u3044\u306A\u3044\u300213\u6642\u9803\u89B3\u5BDF\u3002",
  "id" : 14406597378,
  "created_at" : "2010-05-21 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14095191432",
  "text" : "2010.5.16 \u30B7\u30E9\u30B5\u30AE\u7D0460\u7FBD\u30B4\u30A4\u30B5\u30AE\u7D0420\u7FBD\u3001\u30AB\u30E1\u30E9\u30DE\u30F32\u4EBA\u3001\u6628\u65E5\u3068\u306F\u9055\u3046\u5634\u306E\u9EC4\u8272\u3044\u30C0\u30A4\u30B5\u30AE1\u7FBD\u78BA\u8A8D\u3002\u30B3\u30B5\u30AE\u304C\u3042\u307E\u308A\u76EE\u306B\u3064\u304B\u305A\u3001\u30C1\u30E5\u30A6\u30B5\u30AE\u304C\u76EE\u7ACB\u3063\u305F\u3002\u5348\u5F8C5\u6642\u9803\u89B3\u5BDF\u3002\u30DB\u30B7\u30B4\u30A4\u3068\u30B4\u30A4\u30B5\u30AE\u306F\u534A\u3005\u3050\u3089\u3044\u3002\u30B4\u30A4\u30B5\u30AE\u306F\u6210\u9CE5\u306B\u306A\u308B\u307E\u3067\u306B\uFF12\u5E74\u3050\u3089\u3044\u304B\u304B\u308B\u3088\u3046\u3060\u3002",
  "id" : 14095191432,
  "created_at" : "2010-05-16 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14006266865",
  "text" : "oldsumida\u9589\u9396\u306E\u304A\u77E5\u3089\u305B \u6BCE\u65E5\u306E\u72AC\u306E\u6563\u6B69\u4E2D\u306E\u89B3\u5BDF\u8A18\u9332\u3092\u66F8\u304D\u8FBC\u3093\u3067\u3044\u307E\u3057\u305F\u304C\u3001\u5A18\u304C\u72AC\u306E\u6563\u6B69\u3092\u3059\u308B\u3088\u3046\u306B\u306A\u3063\u305F\u305F\u3081\u3001\u89B3\u5BDF\u304C\u3067\u304D\u306A\u304F\u306A\u308A\u307E\u3057\u305F\u3002\u305D\u3053\u3067\u3001\u3053\u306E\u30B5\u30A4\u30C8\u306F\u9589\u9396\u3057\u307E\u3059\u3002\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u305F\u3060\u3044\u305F\u7686\u3055\u307E\u3001\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3057\u305F\u3002\u8FD1\u65E5\u4E2D\u306B\u30B5\u30AE\u306E\u89B3\u5BDF\u8A18\u9332\u30B5\u30A4\u30C8\u3092\u7ACB\u3061\u4E0A\u3052\u307E\u3059\u3002",
  "id" : 14006266865,
  "created_at" : "2010-05-15 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13537248972",
  "text" : "2010.5.7 \u30A2\u30AA\u30B5\u30AE1(\u5357\u4E2D\u66FD\u6839\uFF09",
  "id" : 13537248972,
  "created_at" : "2010-05-07 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13481573863",
  "text" : "2010.5.6 \u30B7\u30B8\u30E5\u30A6\u30AB\u30E9\u306E\u9CF4\u58F0\uFF08\u91CE\u9CE5\u306E\u68EE\uFF09",
  "id" : 13481573863,
  "created_at" : "2010-05-06 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13419879920",
  "text" : "2010.5.5 \u30E0\u30CA\u30B0\u30ED13(\u5357\u4E2D\u66FD\u6839)",
  "id" : 13419879920,
  "created_at" : "2010-05-05 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]