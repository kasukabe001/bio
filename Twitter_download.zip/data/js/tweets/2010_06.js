Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17153125112",
  "text" : "2010.6.27 16\u6642 \u76EE\u304C\u6163\u308C\u3066\u304D\u305F\u306E\u3068\u96DB\u304C\u5927\u304D\u304F\u306A\u3063\u305F\u306E\u3068\u3067\u96DB\u306E\u6570\u304C\u5897\u3048\u3066\u304D\u305F\u3002A\u30D6\u30ED\u30C3\u30AF\u306E\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u306F10\u7FBD\u3002\u7686\u3001\u7FBD\u3070\u305F\u304D\u306E\u7DF4\u7FD2\u3092\u3057\u3066\u3044\u308B\u3002\u30B7\u30E9\u30B5\u30AE\u306E\u96DB\u304C\u5B75\u3063\u3066\u3044\u308B\u5DE3\u306FA\u304C1\u3001B\u304C4\uFF645\u500B\u3002B\u306B\u306F\u7FBD\u3070\u305F\u304D\u306E\u7DF4\u7FD2\u3092\u3057\u3066\u3044\u308B\u306E\u3082\u3044\u308B\u3002\u7FBD\u306E\u88CF\u306F\u30C8\u30AD\u8272\u3067\u306F\u306A\u3044\u3002\u30A2\u30DE\u30B5\u30AE1\u7FBD\u3002",
  "id" : 17153125112,
  "created_at" : "2010-06-27 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17120183119",
  "text" : "2010.6.26 9\u6642 A\u30D6\u30ED\u30C3\u30AF\u3067\u3082\u30B7\u30E9\u30B5\u30AE\u306E\u96DB\uFF12\u7FBD\u3092\u78BA\u8A8D\u3002B\u30D6\u30ED\u30C3\u30AF\u306B\u982D\u3068\u9996\u306E\u305D\u308C\u305E\u308C\u4E00\u90E8\u304C\u8336\u8272\u306E\u3084\u3084\u5C0F\u3055\u3081\u306E\u30B7\u30E9\u30B5\u30AE\u3092\u78BA\u8A8D\u3002\u30AF\u30C1\u30D0\u30B7\u306F\u9EC4\u8272\u3002\u30A2\u30DE\u30B5\u30AE\u306E\u82E5\u3044\u500B\u4F53\uFF1F\u3002\u30B7\u30E9\u30B5\u30AE\u306E\u5375\u306E\u8272\u306F\u6C34\u8272\u3067\u3042\u308B\u3053\u3068\u3092\u56F3\u9451\u3067\u77E5\u3063\u305F\u3002\u5DE3\u306E\u4E2D\u306B\u3068\u304D\u3069\u304D\u6C34\u8272\u306E\u3082\u306E\u304C\u898B\u3048\u305F\u306E\u306F\u5375\u3060\u3063\u305F\u3093\u3060\u3002",
  "id" : 17120183119,
  "created_at" : "2010-06-26 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17001574837",
  "text" : "2010.6.25 14\u6642 \u65E9\u751F\u307E\u308C\u306E\u96DB\u306F\u968F\u5206\u80B2\u3063\u3066\u3044\u308B\u3002A\u30D6\u30ED\u30C3\u30AF\u3001\u624B\u524D\u306E\u5DE3\u306E2\u7FBD\u3082\u89AA\u4E26\u306E\u5927\u304D\u3055\u306B\u306A\u3063\u3066\u3044\u305F\u3002B\u30D6\u30ED\u30C3\u30AF\u306F\u7FBD\u3070\u305F\u304D\u306E\u7DF4\u7FD2\u3092\u3057\u3066\u3044\u308B\u30B7\u30E9\u30B5\u30AE\u306E\u96DB2\u7FBD\u3092\u3044\u304D\u306A\u308A\u78BA\u8A8D\u3002\u7FBD\u88CF\u306F\u30C8\u30AD\u8272\u3060\u3063\u305F\u3002B\u306F\u30B7\u30E9\u30B5\u30AE\u306E\u30D2\u30CA\u591A\u6570\u3002\u7523\u6BDB\u304C\u767D\u304F\u306A\u308A\u3001\u30B7\u30E9\u30B5\u30AE\u3089\u3057\u304F\u306A\u3063\u305F\u96DB\u3082\u3044\u305F\u3002",
  "id" : 17001574837,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17001716245",
  "text" : "2010.6.25 14\u6642 \u7D9A\u5831 \u30B7\u30E9\u30B5\u30AE\u7D0480\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE\u7D0430\u7FBD\u3002\u30AB\u30E9\u30B9\u306E\u9CF4\u304D\u58F0\u304C\u3088\u304F\u805E\u3053\u3048\u305F\u305F\u305B\u3044\u304B\u3001\u30B5\u30AE\u304C\u4E00\u6589\u306B\u30B3\u30ED\u30CB\u30FC\u4E0A\u3092\u4E71\u821E\u3059\u308B\u3053\u3068\u304C\u3042\u3063\u305F\u3002\u6691\u3044\u305F\u3081\u3001\u7FBD\u3067\u5DE3\u3092\u8986\u3046\u30B7\u30E9\u30B5\u30AE\u304C\u6570\u7FBD\u3044\u305F\u3002\u89B3\u5BDF\u4E2D\u3001\u30AB\u30A4\u30C4\u30D6\u30EA\u306E\u9CF4\u304F\u58F0\u304C\u3088\u304F\u805E\u3053\u3048\u305F\u3002",
  "id" : 17001716245,
  "created_at" : "2010-06-25 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16910774587",
  "text" : "2010.6.23 16\u6642\u9803 \u30B7\u30E9\u30B5\u30AE\u7D0480\u7FBD\u3002\u30B4\u30A4\u30B5\u30AE\u7D0445\u7FBD\u3002A\u30D6\u30ED\u30C3\u30AF\u3001\u4E00\u756A\u76EE\u7ACB\u3064\u30B4\u30A4\u30B5\u30AE\u306E\u96DB2\u7FBD\u3001\u305D\u306E\u96A3\u306E\u5DE3\u306B\u521D\u8A8D1\u7FBD\u3002\uFF22\u30D6\u30ED\u30C3\u30AF\u3001\u30B7\u30E9\u30B5\u30AE\u306E\u5DE3\u306F31.\u30B4\u30A4\u30B5\u30AE\u306E\u96DB1\u7FBD\u3002\u30B7\u30E9\u30B5\u30AE\u306E\u96DB2\u7FBD\u3002B\u30D6\u30ED\u30C3\u30AF\u306F\u96DB\u304C\u5C0F\u3055\u304F\u3066\u3001A\u30D6\u30ED\u30C3\u30AF\u306F\u679D\u3068\u96DB\u304C\u91CD\u306A\u3063\u3066\u3001\u96DB\u3092\u898B\u3064\u3051\u308B\u306E\u304C\u56F0\u96E3\u3002",
  "id" : 16910774587,
  "created_at" : "2010-06-24 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16760499171",
  "text" : "2010.6.22 14\u6642\u9803\u3002\u30B7\u30E9\u30B5\u30AE\u7D0470\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE\u7D0425\u7FBD\u3002A\u30D6\u30ED\u30C3\u30AF\u3067\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u3092\u3055\u3089\u306B2\u7FBD\u78BA\u8A8D\u3002B\u30D6\u30ED\u30C3\u30AF\u3067\u306F\u6628\u65E5\u3068\u306F\u9055\u3046\u5DE3\u3067\u30B7\u30E9\u30B5\u30AE\u306E\u96DB\u30922\u7FBD\u78BA\u8A8D\u3002\u3053\u3061\u3089\u306F\u307E\u3060\u5C0F\u3055\u304F\u3001\u96DB\u3089\u3057\u3044\u3002\u7FBD\u3092\u5E83\u3052\u3066\u5DE3\u3092\u8986\u3046\u30B7\u30E9\u30B5\u30AE\u304C\u76EE\u7ACB\u3064\u3002\u30B4\u30A4\u30B5\u30AE\u306F\u3057\u306A\u3044\u3002A\u30D6\u30ED\u30C3\u30AF\u306E\u30B7\u30E9\u30B5\u30AE\u306E\u5DE3\u306F21\u500B\u3002",
  "id" : 16760499171,
  "created_at" : "2010-06-22 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16682244277",
  "text" : "2010.6.21 14\u6642\u9803\u3002\u30B7\u30E9\u30B5\u30AE\u7D0470\u7FBD(\u30C0\u30A4\u30B5\u30AE2)\u3001\u30B4\u30A4\u30B5\u30AE\u7D0425\u7FBD\u3002\u30B4\u30A4\u30B5\u30AE\u306E\u96DB\u306F\u3055\u3089\u306B\u5927\u304D\u304F\u306A\u3063\u3066\u3044\u305F\u3002\u7FBD\u6BDB\u304C\u81A8\u308C\u3066\u3044\u308B\u306E\u3067\u3001\u89AA\u9CE5\u3088\u308A\u30821\u5468\u308A\u5C0F\u3055\u3044\u7A0B\u5EA6\u306B\u898B\u3048\u308B\u3002B\u30D6\u30ED\u30C3\u30AF\u3067\u3082\u30B4\u30A4\u30B5\u30AE\u306E\u96DB1\u7FBD\u3068\u30C1\u30E5\u30A6\u30B5\u30AE\u306E\u96DB1\u7FBD\u3092\u78BA\u8A8D\u3002\u7FBD\u3092\u5E83\u3052\u3066\u5DE3\u3092\u8986\u3046\u89AA\u3084\u3001\u5C0F\u679D\u3092\u904B\u3076\u500B\u4F53\u3082\u3044\u305F\u3002",
  "id" : 16682244277,
  "created_at" : "2010-06-21 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16604127586",
  "text" : "2010.6.20 15\u6642 \u30B4\u30A4\u30B5\u30AE\u306E\u30D2\u30CA\u306F\uFF14\u7FBD\u3002\u4E0B\u306E\u5DE3\u306B\u3082\u30461\u7FBD\u3044\u305F\u3002\u4E00\u6628\u65E5\u3088\u308A\u4E00\u56DE\u308A\u5927\u304D\u304F\u306A\u308A\u3001\u89AA\u9CE5\u306E\u534A\u5206\u3050\u3089\u3044\u3042\u308B\u611F\u3058\u3002\u30A2\u30AA\u30B5\u30AE\u5E7C\u9CE5(\u4ECA\u5E74\u5DE3\u7ACB\u3061?)\u304C\u4E00\u7FBD\u3001\u5730\u9762\u306B\u6B62\u307E\u3063\u3066\u3044\u305F\u3002\u30B4\u30A4\u30B5\u30AE\u7D0445\u7FBD\u3001\u30B7\u30E9\u30B5\u30AE\u7D0490\u7FBD(\u30C0\u30A4\u30B5\u30AE\u306F\u7D044\u7FBD)\u3002\u30AB\u30E9\u30B91\u7FBD\u304C\u4E0A\u7A7A\u3092\u76DB\u3093\u306B\u821E\u3046\u3002\u9CE5\u898B\u5BA22\u4EBA\u3002",
  "id" : 16604127586,
  "created_at" : "2010-06-20 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16534623468",
  "text" : "Block B http:\/\/twitpic.com\/1y2j0t",
  "id" : 16534623468,
  "created_at" : "2010-06-19 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16534918943",
  "text" : "A\u30D6\u30ED\u30C3\u30AF\u3067\u3059\u3002 http:\/\/twitpic.com\/1y2lan",
  "id" : 16534918943,
  "created_at" : "2010-06-19 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16448959842",
  "text" : "2010.6.18 7\u6642 \u30B7\u30E9\u30B5\u30AE\u7D04100\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE35\u7FBD\u5F37\u3001\u30D2\u30CA\u306F3\u7FBD\u30022\u65E5\u524D\u3088\u308A\u4E00\u56DE\u308A\u5927\u304D\u304F\u306A\u3063\u3066\u3044\u308B\u30023\u7FBD\u4EE5\u5916\u306E\u30D2\u30CA\u3092\u78BA\u8A8D\u3067\u304D\u306A\u3044\u306E\u304C\u6B8B\u5FF5\u3002\u30A2\u30DE\u30B5\u30AE2\u7FBD\u304C\u5FA9\u6D3B\u3002\u5634\u306E\u30D4\u30F3\u30AF\u304C\u9BAE\u3084\u304B\u306B\u306A\u3063\u3066\u304D\u305F\u3002\u5074\u306B\u4E9C\u9EBB\u8272\u306E\u7FBD\u306F\u306A\u3044\u304C\u3001\u5634\u304C\u30A2\u30DE\u30B5\u30AE\u3068\u540C\u8272\u306E\u500B\u4F53\u304C\u3044\u305F\u3002\u304A\u305D\u3089\u304F\u30A2\u30DE\u30B5\u30AE\u3060\u3002",
  "id" : 16448959842,
  "created_at" : "2010-06-18 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16281000365",
  "text" : "20106.16 13:30\u3000\u30B4\u30A4\u30B5\u30AE\u306E\u30D2\u30CA\u3092\u78BA\u8A8D\u3002\u89AA\u9CE5\u306E4\u5206\u306E1\u304F\u3089\u3044\u3042\u3063\u305F\u3002\u5148\u65E5\u6765\u306E\u30C1\u30C3\u30C1\u30C3\u30C1\u3068\u3044\u3046\u9CF4\u304D\u58F0\u304C\u30D2\u30CA\u306E\u3082\u306E\u3060\u3063\u305F\u3088\u3046\u3060\u30022\u3064\u306E\u5DE3\u3067\u8A083\u7FBD\u306E\u30D2\u30CA\u3092\u78BA\u8A8D\u3057\u305F\u304C\u3001\u58F0\u304B\u3089\u5224\u65AD\u3059\u308B\u3068\u3001\u3082\u3046\u5C11\u3057\u3044\u305D\u3046\u3002\u96DB\u306F\u7523\u6BDB(?)\u3068\u9EC4\u8272\u3044\u811A\u304C\u3088\u304F\u76EE\u7ACB\u3063\u305F\u3002\u96DB\u306E\u8A95\u751F\u306F\u3084\u306F\u308A\u3001\u3046\u308C\u3057\u3044\u3002",
  "id" : 16281000365,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16281257917",
  "text" : "2010.6.16 \u7D9A\u5831 \u30B7\u30E9\u30B5\u30AE\u7D0485\u7FBD\u3002\u30B4\u30A4\u30B5\u30AE\u7D0420\u7FBD\u3067\u5DE3\u306F7\u3064\u78BA\u8A8D\u3002\u30B7\u30E9\u30B5\u30AE\u306E\u30D2\u30CA\u306F\u78BA\u8A8D\u3067\u304D\u306A\u304B\u3063\u305F\u3002\u7FBD\u3092\u5E83\u3052\u3066\u3001\u5DE3\u3092\u65E5\u5149\u304B\u3089\u5B88\u3063\u3066\u3044\u308B\u3088\u3046\u306A\u3057\u3050\u3055\u3092\u898B\u305B\u305F\u30B7\u30E9\u30B5\u30AE\u304C\u3044\u305F\u3002\u30AB\u30E9\u30B9\u304C1\u7FBD\u3001\u30B3\u30ED\u30CB\u30FC\u3092\u304B\u3059\u3081\u3066\u98DB\u3093\u3067\u3044\u3063\u305F\u3002\u76EE\u306E\u5468\u308A\u304C\u7DD1\u306E\u30C0\u30A4\u30B5\u30AE1\u7FBD\u3002\u30A2\u30DE\u30B5\u30AE\u306F\u3044\u306A\u3044\u3002",
  "id" : 16281257917,
  "created_at" : "2010-06-16 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16205867153",
  "text" : "2010.6.15 13:30\u9803 \u30B4\u30A4\u30B5\u30AE15\u7FBD\u5F37\u3001\u5DE3\u306F5,6\u500B\u3002\u30B7\u30E9\u30B5\u30AE\u7D0485\u7FBD\u3001\u5DE340\u500B\u3050\u3089\u3044\u3002\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u306B\u306F\u30B5\u30B5\u30B4\u30A4\u3082\u3044\u308B\u3053\u3068\u304C\u3042\u308B\u3089\u3057\u3044\u304C\u3001\u3053\u3053\u3067\u306F\u898B\u3066\u3044\u306A\u3044\u3002\u30B5\u30AE\u304C\u55B6\u5DE3\u3057\u3066\u3044\u308B\u7B87\u6240\u306F\u6797\u306E\u4E2D\u306E\uFF12\u7B87\u6240\u306B\u96C6\u4E2D\u3057\u3066\u3044\u308B\u306E\u3060\u304C\u3001\u3069\u3061\u3089\u3082\u8449\u304C\u843D\u3061\u3066\u3001\u67AF\u308C\u6728\u72B6\u614B\u306B\u306A\u3063\u3066\u304D\u305F\u3002",
  "id" : 16205867153,
  "created_at" : "2010-06-15 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16070509851",
  "text" : "2010.6.13 16\u6642\u9803\u3000\u30B7\u30E9\u30B5\u30AE\u7D0490\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE15\u7FBD\u5F37\u3002\u30C0\u30A4\u30B5\u30AE\u304C\u76EE\u306B\u3064\u3044\u305F\u3002\u76EE\u306E\u5468\u308A\u304C\u7DD1\u304C2\u7FBD\u3001\u5634\u9EC4\u8272\u304C1\u7FBD\u3002\u30C0\u30A4\u30B5\u30AE\u306E\u5927\u304D\u3055\u3068\u3044\u3046\u304B\u9996\u306E\u9577\u3055\u306F\u969B\u7ACB\u3064\u3002\u30A2\u30DE\u30B5\u30AE\u306F\u3044\u306A\u3044\u3002\u30C1\u30C3\u30C1\u30C3\u30C1\u3068\u3044\u3046\u58F0\u306F\u4ECA\u65E5\u3082\u805E\u3053\u3048\u305F\u304C\u3001\u30D2\u30CA\u304C\u5B75\u3063\u3066\u3044\u308B\u306E\u304B\u3069\u3046\u304B\u306F\u4E0D\u660E\u306E\u307E\u307E\u3002",
  "id" : 16070509851,
  "created_at" : "2010-06-13 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15987792857",
  "text" : "2010.6.12 15\u9803\u3000\u30B7\u30E9\u30B5\u30AE\u7D0480\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE\u7D0415\u7FBD\u3002\u30A2\u30DE\u30B5\u30AE\u306F\u3044\u306A\u3044\u3002\u30C1\u30C3\u30C1\u30C3\u3068\u3044\u3046\u58F0\u304C\u805E\u3053\u3048\u308B\u304C\u30B9\u30BA\u30E1\u306A\u306E\u304B\u3001\u30D2\u30CA\u306E\u58F0\u306A\u306E\u304B\u5224\u5225\u3067\u304D\u306A\u3044\u3002\u30AB\u30E9\u30BA\u304C2\u7FBD\u3001\u30B3\u30ED\u30CB\u30FC\u306E\u4E0A\u3092\u821E\u3063\u3066\u3044\u305F\u3002\u3082\u3057\u304B\u3057\u3066\u3001\u30D2\u30CA\u3092\u72D9\u3063\u3066\u3044\u308B\uFF1F\u3002\u30D2\u30CA\u304C\u3044\u308B\u306E\u304B\u3069\u3046\u304B\u3001\u4F55\u3068\u3082\u8A00\u3048\u307E\u305B\u3093\u3002",
  "id" : 15987792857,
  "created_at" : "2010-06-12 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15914704026",
  "text" : "2010.6.11 17\u6642 \u30A2\u30DE\u30B5\u30AE2\u7FBD\u767B\u5834!\u3002\u9BAE\u3084\u304B\u306A\u4E9C\u9EBB\u8272\u3001\u5F53\u305F\u308A\u524D\u304B\u3002\u982D\u3001\u9996\u3001\u305D\u3057\u30661\u7FBD\u306F\u80CC\u4E2D\u3082\u4E9C\u9EBB\u8272\u3060\u3063\u305F\u3002\u30B7\u30E9\u30B5\u30AE\u7D04100\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE\u7D0410\u7FBD\u3002\u30D2\u30CA\u304C\u5B75\u3063\u305F\u6C17\u914D\u306F\u306A\u3044\u3002",
  "id" : 15914704026,
  "created_at" : "2010-06-11 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15684921991",
  "text" : "2010.6.7 13\u6642\u9803 \u30B7\u30E9\u30B5\u30AE90\u7FBD\u5F37\u3001\u30B4\u30A4\u30B5\u30AE\u7D0415\u7FBD\u3002\u30B4\u30A4\u30B5\u30AE\u306F\u6210\u9577\u3068\u5E7C\u9CE5\u306E\u4F53\u8272\u304C\u306F\u3063\u304D\u308A\u3068\u7570\u306A\u308B\u304C\u3001\u4E2D\u9593\u7684\u306A\u500B\u4F53\u304C\u898B\u53D7\u3051\u3089\u308C\u306A\u3044\u3002\u3053\u306E\u30B3\u30ED\u30CB\u30FC\u306B\u306F\u305F\u307E\u305F\u307E\u305D\u3046\u3044\u3046\u500B\u4F53\u304C\u3044\u306A\u3044\u306E\u304B\u3001\u305D\u308C\u3068\u3082\u3001\u77ED\u671F\u9593\u306B\u4E00\u6C17\u306B\u4F53\u8272\u304C\u5909\u5316\u3059\u308B\u306E\u304B\u7591\u554F\u3060\u3002",
  "id" : 15684921991,
  "created_at" : "2010-06-08 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15555668122",
  "text" : "2010.6.6 17\u6642\u9803 \u30B7\u30E9\u30B5\u30AE80\u7FBD\u5F37\u3001\u30B4\u30A4\u30B5\u30AE10\u7FBD\u5F37\u3002\u30D2\u30CA\u306E\u58F0\u306F\u805E\u3053\u3048\u305A\u3002Yahoo\u30AA\u30F3\u30E9\u30A4\u30F3\u91CE\u9CE5\u56F3\u9451\u306B\u3088\u308B\u3068\u62B1\u5375\u671F\u9593\u306F\u30B3\u30B5\u30AE22~24\u65E5\u3001\u30C1\u30E5\u30A6\u30B5\u30AE24~27\u65E5\u3001\u30C0\u30A4\u30B5\u30AE\u7D0425\u65E5\u3002\u62B1\u5375\u3057\u3066\u3044\u308B\u59FF\u304C\u898B\u3048\u59CB\u3081\u305F\u306E\u306F\u5148\u670820\u65E5\u904E\u304E\u9803\u304B\u3089\u3002\u4ECA\u9031\u672B\u9803\u306B\u306F\u30D2\u30CA\u304C\u8A95\u751F\u3059\u308B\u304B\u3082\u3002",
  "id" : 15555668122,
  "created_at" : "2010-06-06 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15486053049",
  "text" : "2010.6.5 17\u6642\u9803 \u30B7\u30E9\u30B5\u30AE80\u7FBD\u5F37\u3001\u30B4\u30A4\u30B5\u30AE\u7D0410\u7FBD\u3002\u4ECA\u65E5\u3082\u30B4\u30A4\u30B5\u30AE\u304C\u5C11\u306A\u3044\u3002\u30D2\u30CA\u304C\u3044\u308B\u6C17\u914D\u306F\u306A\u3044\u3002\u30C0\u30A4\u30B5\u30AE\u306F\u76EE\u306E\u5468\u308A\u7DD1\u3068\u5634\u9EC4\u8272\u304C1\u7FBD\u305A\u3064\u3002\u4E26\u3093\u3067\u898B\u7269\u3057\u3066\u3044\u305F\u304A\u3058\u3055\u3093\u306F\u300C\u30A2\u30AA\u30B5\u30AE\u3082\u3044\u308B\u300D\u3068\u8A00\u3063\u3066\u3044\u305F\u304C\u3001\u308F\u3057\u306F\u898B\u3061\u3087\u3089\u3093\u3002\u3053\u306E\u30B3\u30ED\u30CB\u30FC\u306F\u53BB\u5E74\u3082\u3042\u3063\u305F\u3053\u3068\u3092\u6559\u3048\u3066\u3082\u3089\u3063\u305F\u3002",
  "id" : 15486053049,
  "created_at" : "2010-06-05 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15399687656",
  "text" : "2010.6.5 11:30\u9803 \u30B7\u30E9\u30B5\u30AE105\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE12\uFF653\u7FBD\u3002\u30B4\u30A4\u30B6\u30AE\u306F\u591A\u3044\u3068\u304D\u3068\u5C11\u306A\u3044\u3068\u304D\u304C\u3042\u308B\u3002\u30D2\u30CA\u304C\u5B75\u3063\u3066\u3044\u308B\u69D8\u5B50\u306F\u306A\u3044\u3002\u89B3\u5BDF\u304B\u3089\u306E\u5E30\u308A\u9053\u3001\u539F\u56E0\u306F\u4E0D\u660E\u3060\u304C\u98DB\u3076\u3053\u3068\u304C\u3067\u304D\u306A\u3044\u30AB\u30E9\u30B9\u306E\u5E7C\u9CE5\u304C\u9053\u7AEF\u304B\u3089\u9053\u8DEF\u306B\u3055\u307E\u3088\u3044\u51FA\u3066\u3001\u8ECA\u306B\u8F62\u304B\u308C\u305F\u3002\u89AA\u9CE5\u3089\u3057\u30442\u7FBD\u304C\u3057\u304D\u308A\u306B\u9CF4\u3044\u3066\u3044\u305F\u3002",
  "id" : 15399687656,
  "created_at" : "2010-06-04 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15313705748",
  "text" : "2010.6.4 16\u6642\u9803\u3000\u30B7\u30E9\u30B5\u30AE80\u7FBD\u3001\u30B4\u30A4\u30B5\u30AE\u306F15\u7FBD\u5F31\u3068\u5C11\u306A\u3044\u3002\u30D2\u30CA\u306E\u58F0\u306F\u805E\u3053\u3048\u306A\u3044\u3002\u62B1\u5375\u30DD\u30FC\u30BA\u306E\u30B7\u30E9\u30B5\u30AE\u306F40\u3050\u3089\u3044\u3002\u30C0\u30A4\u30B5\u30AE\u306F\u76EE\u306E\u5468\u308A\u7DD1\u304C2\u3001\u5634\u9EC4\u8272\u304C1\uFF0E\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u306B\u6765\u308B\u9014\u4E2D\u306E\u6C34\u7530\u3067\u30BB\u30C3\u30AB\u3092\u898B\u305F\uFF08\u805E\u3044\u305F\uFF09\u3002",
  "id" : 15313705748,
  "created_at" : "2010-06-03 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]