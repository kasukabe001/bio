Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437523699382484992",
  "text" : "\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306B\u51FA\u4F1A\u3048\u305A\u3001\u5E30\u308D\u3046\u3068\u3057\u305F\u3068\u304D\u3001\u9060\u65B9\u306B\u65CB\u56DE\u98DB\u884C\u4E2D\u306E\u7FA4\u308C\u3092\u767A\u898B\u3002\u81EA\u8EE2\u8ECA\u3067\u79FB\u52D5\u3057\u3001\u7FA4\u308C\u306E\u7740\u5730\u70B9\u306B\u5230\u7740\u3002250~300\u7FBD\u3002\u7530\u3093\u307C\u3067\u6355\u98DF\u4E2D\u306E\u7FA4\u308C\u304B\u3089\u5C11\u3057\u96E2\u308C\u305F\u6797\u306B\u3082\u7D0420\u7FBD\u306E\u30AB\u30E9\u30B9\u3002\u8FD1\u3065\u304F\u3068\u732B\u307F\u305F\u3044\u306A\u5909\u306A\u9CF4\u304D\u58F0\u3002\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u3088\u308A\u3082\u660E\u3089\u304B\u306B\u5C0F\u3055\u3044\u500B\u4F53\u304C\u3044\u308B\u3002\u9ED2\u8272\u7CFB\u30B3\u30AF\u30DE\u30EB\u3060\u3002",
  "id" : 437523699382484992,
  "created_at" : "2014-02-23 09:45:53 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]