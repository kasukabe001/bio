Grailbird.data.tweets_2010_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9657267286",
  "text" : "2010.2.26 \u30AA\u30CA\u30AC1,\u30B7\u30B8\u30E5\u30A6\u30AB\u30E91\uFF08\u91CE\u9CE5\u306E\u68EE\uFF09",
  "id" : 9657267286,
  "created_at" : "2010-02-26 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9608328415",
  "text" : "2010.2.25 \u30E2\u30BA1(\u91CE\u9CE5\u306E\u68EE\uFF64\u7551\u3068\u306E\u5883) \u3001\u30AA\u30AA\u30B8\u30E5\u30EA\u30F32(\u65E7\u53E4\u9685\u7530\u5DDD)",
  "id" : 9608328415,
  "created_at" : "2010-02-25 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9476035536",
  "text" : "2010.2.22 \u30B7\u30E1\u306E\u9CF4\u58F0\uFF08\u3044\u3064\u3082\u306E\u6CBC\uFF09",
  "id" : 9476035536,
  "created_at" : "2010-02-22 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9329015175",
  "text" : "2010.2.19 \u30E2\u30BA1(\u91CE\u9CE5\u306E\u68EE\u306E\u7AEF\u3001\u7551\u3068\u306E\u5883\u754C\u306B\u3042\u308B\u6728\u306E\u679D)",
  "id" : 9329015175,
  "created_at" : "2010-02-19 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9304781388",
  "text" : "2009.2.18 \u30B3\u30B2\u30E91\uFF08\u91CE\u9CE5\u306E\u68EE) \u521D\u3081\u3066\u9CF4\u58F0\u3067\u8A8D\u8B58\u3002\u30A6\u30B0\u30A4\u30B91(\u81EA\u5B85\u5EAD)",
  "id" : 9304781388,
  "created_at" : "2010-02-18 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9119679033",
  "text" : "2010.2.14 \u30AA\u30CA\u30AC1\u7FBD\u3060\u3051\uFF08\u91CE\u9CE5\u306E\u68EE\uFF09",
  "id" : 9119679033,
  "created_at" : "2010-02-15 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8893252949",
  "text" : "2010.2.10 \u30B7\u30ED\u30CF\u30E91(\u91CE\u9CE5\u306E\u68EE\u30FB\u5730\u9762)",
  "id" : 8893252949,
  "created_at" : "2010-02-10 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8833612782",
  "text" : "2010.2.9 \u3044\u3064\u3082\u306E\u6CBC\u3001\u6C34\u9762\u304B\u3089\u679D\u3092\u7A81\u304D\u51FA\u3057\u3066\u3044\u308B\u5012\u6728\u306E\u4E0A\u3067\u30E0\u30AF\u30C9\u30EA\u304C\u6C34\u6D74\u3073",
  "id" : 8833612782,
  "created_at" : "2010-02-09 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8795395776",
  "text" : "2010.2.7 \u30AB\u30EF\u30E9\u30D2\u30E91(\u7ACB\u91CE\u5C0F\u5074)",
  "id" : 8795395776,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8795430409",
  "text" : "2010.2.8 \u30B3\u30B5\u30AE1(\u8C4A\u6625\u5C0F\u5074)\uFF64\u30E2\u30BA1(\u91CE\u9CE5\u306E\u68EE\u306E\u7AEF\u3001\u7551\u3068\u306E\u5883\u754C)\u3001\u30B3\u30AC\u30E25(\u65E7\u53E4\u9685\u7530\u5DDD)",
  "id" : 8795430409,
  "created_at" : "2010-02-08 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8676728562",
  "text" : "2010.2.5 \u30A2\u30AA\u30B8\u26401\u3001\u30B8\u30E7\u30A6\u30D3\u30BF\u30AD\u26401\uFF08\u6211\u304C\u5BB6\u306E\u5EAD\uFF09",
  "id" : 8676728562,
  "created_at" : "2010-02-05 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8623283774",
  "text" : "2010.2.5 \u30C0\u30A4\u30B5\u30AE1\uFF08\u8C4A\u6625\u5C0F\u5074\uFF09\u3001\u30B3\u30AC\u30E23",
  "id" : 8623283774,
  "created_at" : "2010-02-04 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8530243965",
  "text" : "2010.2.2 \u30BB\u30B0\u30ED\u30AB\u30E2\u30E11\u3001\u30BB\u30B0\u30ED\u30BB\u30AD\u30EC\u30A41(\u53E4\u5229\u6839\u5DDD)",
  "id" : 8530243965,
  "created_at" : "2010-02-02 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]