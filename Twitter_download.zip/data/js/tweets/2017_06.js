Grailbird.data.tweets_2017_06 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "878589561995108352",
  "text" : "2\u5E74\u632F\u308A\u306B\u6295\u7A3F\u3002\u4ECA\u5E74\u306F1\u6708\u306B\u56FD\u905316\u53F7\u7DDA\u6CBF\u3044\u306B\u96FB\u7DDA\u306B\u6B62\u307E\u3063\u3066\u3044\u308B\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306E\u7FA4\u308C\u3092\u767A\u898B\u3002100\u7FBD\u4EE5\u4E0A\u3044\u305F\u3002\u7530\u3093\u307C\u4EE5\u5916\u306E\u5834\u6240\u3067\u898B\u3064\u3051\u308B\u3053\u3068\u304C\u3067\u304D\u3066\u3001\u3046\u308C\u3057\u304B\u3063\u305F\u30025\u6708\u306B\u306F\u30DB\u30AA\u30B8\u30ED\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u309240\u5E74\u632F\u308A\u306B\u78BA\u8A8D\u30022\u56DE\u76EE\u306E\u78BA\u8A8D\u3060\u304C\u30013\u56DE\u76EE\u306F\u3042\u308B\u306E\u3060\u308D\u3046\u304B\u3002",
  "id" : 878589561995108352,
  "created_at" : "2017-06-24 12:24:09 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]