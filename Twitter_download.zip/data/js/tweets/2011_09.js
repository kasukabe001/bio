Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113269407320522752",
  "text" : "2011.7.10  14\u6642\u9803\u3001\u30B7\u30E9\u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u8DE1\u306B\u30DB\u30B7\u30B4\u30A46\u7FBD\u3001\u30A2\u30AA\u30B5\u30AE1\u7FBD\u3002",
  "id" : 113269407320522752,
  "created_at" : "2011-09-12 15:15:05 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]