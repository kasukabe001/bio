Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62288880921100288",
  "text" : "2011.4.24 \u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u8DE1\u3092\u8A2A\u308C\u308B\u304C\u3001\u30B5\u30AE\u306F\u3044\u306A\u3044\u3002\u30D6\u30EB\u30C9\u30FC\u30B6\u30FC\u3067\u6574\u5730\u3055\u308C\u305F\u6CB3\u539F\u306B\u306F\u91E3\u308A\u4EBA\u304C\u3044\u305F\u3002\u6094\u3057\u3044\uFF01\u3002",
  "id" : 62288880921100288,
  "created_at" : "2011-04-24 22:56:41 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60189580233687040",
  "text" : "2011.4.17 \u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306F\u3044\u306A\u304B\u3063\u305F\u3002\u5317\u3078\u5E30\u3063\u305F\u306E\u3060\u308D\u3046\u3002\u5317\u3078\u5E30\u3063\u305F\u3068\u3044\u3046\u3068\u7C21\u5358\u3060\u304C\u3001\u65E5\u672C\u306E\u3069\u306E\u8FBA\u308A\u3092\u901A\u3063\u3066\u3001\u5927\u9678\u306E\u3069\u306E\u8FBA\u308A\u3067\u590F\u3092\u904E\u3054\u3059\u306E\u3060\u308D\u3046\u304B\u3002\u308F\u304B\u3089\u306A\u3044\u3053\u3068\u3070\u304B\u308A\u3002",
  "id" : 60189580233687040,
  "created_at" : "2011-04-19 03:54:48 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54859802467254272",
  "text" : "2011.4.4 \u98FE\u308A\u7FBD\u306E\u5148\u7AEF\u304C\u4E9C\u9EBB\u8272\u306E\u30C0\u30A4\u30B5\u30AE\u3092\u4ECA\u65E5\u3082\u81EA\u5B85\u5074\u306E\u6C34\u8DEF\u3067\u898B\u305F\u3002\u8FD1\u304F\u306B\u3044\u305F\u30B3\u30B5\u30AE\u3082\u5C3E\u7FBD\u306E\u5148\u304C\u4E9C\u9EBB\u8272\u3060\u3063\u305F\u306E\u3067\u3001\u3069\u3076\u5DDD\u306E\u3088\u3046\u306A\u6C34\u8DEF\u306E\u305F\u3081\u3001\u6C34\u306B\u3064\u304B\u3063\u305F\u90E8\u5206\u304C\u6C5A\u308C\u3066\u3044\u308B\u3060\u3051\u3060\u3068\u5224\u660E\u3002\u4EE5\u5F8C\u3001\u8336\u8272\u3068\u8868\u8A18\u3059\u308B\u3002\u3057\u304B\u3057\u3001\u30C0\u30A4\u30B5\u30AE\u304C\u540C\u3058\u500B\u4F53\u3067\u3042\u308B\u3053\u3068\u306F\u9593\u9055\u3044\u306A\u3044\u3002",
  "id" : 54859802467254272,
  "created_at" : "2011-04-04 10:56:10 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54858249861738497",
  "text" : "2011.4.2 \u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u7D0450\u3002\u304A\u305D\u3089\u304F\u3001\u3059\u3079\u3066\u7B2C\uFF11\u56DE\u51AC\u7FBD\u3002\u7530\u3092\u6398\u308A\u8FD4\u3059\u8015\u904B\u6A5F\u306E\u5468\u56F2\u306B\u7FA4\u308C\u3066\u3044\u305F\u3002",
  "id" : 54858249861738497,
  "created_at" : "2011-04-04 10:50:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54471606835232768",
  "text" : "2011.4.2 \u98FE\u308A\u7FBD\u306E\u5148\u7AEF\u304C\u30A2\u30DE\u30B5\u30AE\u306E\u3088\u3046\u306B\u4E9C\u9EBB\u8272\u306E\u30C0\u30A4\u30B5\u30AE\u3092\u898B\u305F\u3002\u76EE\u306E\u5468\u56F2\u306F\u7DD1\u8272\u306B\u306A\u308A\u3064\u3064\u3042\u308B\u3002\u81EA\u5B85\u304B\u30892Km\u3050\u3089\u3044\u96E2\u308C\u305F\u5730\u70B9\u3067\u5348\u5F8C\u4E00\u6642\u9803\u306B\u898B\u305F\u306E\u3060\u304C\u30014\u6642\u904E\u304E\u306B\u4ECA\u5EA6\u306F\u81EA\u5B85\u5074\u306E\u6C34\u8DEF\u3067\u898B\u3064\u3051\u305F\u3002\u500B\u4F53\u8B58\u5225\u3067\u304D\u308B\u3068\u3001\u4E00\u65E5\u306E\u52D5\u304D\u307E\u3067\u5206\u304B\u308B\u3002",
  "id" : 54471606835232768,
  "created_at" : "2011-04-03 09:13:37 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54469556797833216",
  "text" : "2011.4.2 \u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u8DE1\u3067\u5516\u7136\u3002\u30D6\u30EB\u30C9\u30FC\u30B6\u30FC\u304C\u5165\u3063\u3066\u3001\u6574\u5730\u3057\u3066\u3044\u305F\u3002\u4E0A\u6D41\u5074\u306E\u534A\u5206\u306F\u6B8B\u308A\u305D\u3046\u3060\u304C\u3001\u6574\u5730\u3057\u305F\u5F8C\u306B\u5EFA\u7269\u304C\u3067\u304D\u308C\u3070\u3001\u30B5\u30AE\u306F\u3084\u3063\u3066\u3053\u306A\u3044\u3002\u60B2\u3057\u3044\u3002",
  "id" : 54469556797833216,
  "created_at" : "2011-04-03 09:05:28 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53753173755699200",
  "text" : "2011.3.27 \u30B5\u30AE\u306E\u30B3\u30ED\u30CB\u30FC\u8DE1\u3001\u30B5\u30AE\u306F\u3044\u306A\u3044\u30022011.4.1 \u53E4\u5229\u6839\u5DDD\u3067\u30B4\u30A4\u30B5\u30AE12\u7FBD\u3002\u3046\u30612\u7FBD\u306F\u30DB\u30B7\u30B4\u30A4\u3002",
  "id" : 53753173755699200,
  "created_at" : "2011-04-01 09:38:49 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]