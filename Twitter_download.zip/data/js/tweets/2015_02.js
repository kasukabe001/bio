Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563985666879811584",
  "text" : "2\u9031\u7D9A\u304D\u306E\u7A7A\u632F\u308A\u306B\u3081\u3052\u305A\u3001\u4ECA\u65E5\u306F\u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u3068\u906D\u9047\u300260\u7FBD\u3050\u3089\u3044\u3002\u30AB\u30E9\u30B9\u306E\u7FA4\u308C\u306F\u3082\u3063\u3068\u5927\u304D\u304B\u3063\u305F\u306E\u3060\u304C\u3001\u5DE6\u306E\u90E8\u5206\u3060\u3051\u304C\u30DF\u30E4\u30DE\u3001\u4E2D\u592E\u3068\u53F3\u5074\u306F\u30CF\u30B7\u30DC\u30BD\u30AC\u30E9\u30B9\u3002\u30CF\u30B7\u30DC\u30BD\u306B\u898B\u3048\u305F\u4E2D\u306B\u306F\u30DF\u30E4\u30DE\u306E\u82E5\u9CE5\u3082\u3044\u305F\u306E\u304B\u3082\u77E5\u308C\u306A\u3044\u3002",
  "id" : 563985666879811584,
  "created_at" : "2015-02-07 09:00:35 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]