Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472713259552747520",
  "text" : "\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u306E\u5852\u3092\u767A\u898B\u3002\u524D\u56DE\u306F\u5409\u91CE\u5C4B\u5074\u306E\u8857\u8DEF\u6A39\u3060\u3063\u305F\u304C\u3001\u4ECA\u56DE\u306F\u6771\u6B66\u30B9\u30C8\u30A2\u306E\u51FA\u5165\u308A\u53E3\u6A2A\u3002\u9589\u5E97\u6642\u523B\u306F\u5348\u524D\uFF11\u6642\u3002\u660E\u308B\u3044\u591C\u304C\u597D\u304D\u306A\u3088\u3046\u3060\u3002\u901A\u308A\u306B\u6CBF\u3063\u3066\u690D\u3048\u3089\u308C\u305F\u8857\u8DEF\u6A39\u306E\u4E00\u756A\u7AEF\u3001\u3064\u307E\u308A\u3001\u4EA4\u5DEE\u70B9\u306E\u3059\u3050\u5074\u3068\u3044\u3046\u7ACB\u5730\u6761\u4EF6\u307E\u3067\u4E00\u81F4\u3057\u3066\u3044\u308B\u3002\u6A39\u7A2E\u306F\u672A\u78BA\u8A8D\u3002\u524D\u56DE\u306F\u30E6\u30EA\u30CE\u30AD\u3060\u3063\u305F\u3002",
  "id" : 472713259552747520,
  "created_at" : "2014-05-31 12:16:38 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]