Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41812950696214528",
  "text" : "\u30E2\u30CB\u30BF\u30EA\u30F3\u30B0\u30B5\u30A4\u30C81000 \u30AC\u30F3\u30AB\u30E2\u985E\u8ABF\u67FB \u4EA4\u6D41\u4F1A\u300C\u6771\u4EAC\u6E7E\u306E\u30AC\u30F3\u30AB\u30E2\u3001\u3044\u307E\u3080\u304B\u3057\u300D\u3068\u3044\u3046\u306E\u306B\u53C2\u52A0\u3057\u3066\u304D\u305F\u3002\u30AB\u30E2\u306E\u751F\u606F\u6570\u8ABF\u67FB\u3092\u3084\u3063\u3066\u307F\u3088\u3046\u3068\u3044\u3046\u6C17\u306B\u306A\u3063\u305F\u3002\u5143\u8352\u5DDD\u306B\u306F\u30D2\u30C9\u30EA\u30AC\u30E2\u3068\u30B3\u30AC\u30E2\u306F\u305F\u304F\u3055\u3093\u3044\u308B\u3002\u30AA\u30CA\u30AC\u30AC\u30E2\u3082\u3068\u304D\u3069\u304D\u3044\u308B\u3002\u30DE\u30AC\u30E2\u3082\u898B\u305F\u3053\u3068\u304C\u3042\u308B\u3002",
  "id" : 41812950696214528,
  "created_at" : "2011-02-27 10:52:38 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41024510668980224",
  "text" : "2011.2.25 \u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u3092\u89B3\u5BDF\u3067\u304D\u305F\u3002\u3061\u306A\u307F\u306B19\u65E5\u306F\u7A7A\u632F\u308A\u3060\u3063\u305F\u3002\u8FD1\u8DDD\u96E2\u306B\u8FD1\u3065\u3051\u305F\u306E\u3067\u3001\u5634\u306E\u8272\u3068\u5F62\u3067\u306F\u3063\u304D\u308A\u3068\u30DF\u30E4\u30DE\u3068\u8B58\u5225\u3067\u304D\u305F\u3002\u5E83\u3044\u6C34\u7530\u5730\u5E2F\u306E\u4E2D\u3067\u3001\u30DF\u30E4\u30DE\u304C\u3044\u308B\u306E\u306F\u9650\u3089\u308C\u305F\u7BC4\u56F2\u3067\u3001\u30CF\u30B7\u30D6\u30C8\u3068\u30CF\u30B7\u30DC\u30BD\u306F\u3082\u3063\u3068\u5E83\u3044\u5730\u57DF\u3067\u78BA\u8A8D\u3067\u304D\u308B\u3002\u3053\u306E\u5DEE\u306F\u306A\u305C\uFF1F\u3002\u4ED6\u306B\u30DB\u30AA\u30B8\u30ED\u3001\u30BF\u30B2\u30EA\u3002",
  "id" : 41024510668980224,
  "created_at" : "2011-02-25 06:39:40 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haku",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37806819162337280",
  "text" : "#haku \u4E45\u3005\u306B\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u306E\u8A71\u984C\u3002\u30A2\u30CB\u30DE1981\u5E746\u6708\u53F7\u3067\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u306E\u5852\u306E\u8A18\u4E8B\u3092\u767A\u898B\u3002\u4EA4\u901A\u91CF\u304C\u591A\u3044\u9053\u8DEF\u306E\u5074\u3001\u591C\u3067\u3082\u660E\u308B\u3044\u6240\u306B\u5852\u3092\u4F5C\u308B\u306E\u306F\u73CD\u3057\u304F\u306A\u3044\u3089\u3057\u3044\u3002",
  "id" : 37806819162337280,
  "created_at" : "2011-02-16 09:33:42 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37011427688591360",
  "text" : "2011.2.13 \u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306F40~50\u7FBD?\uFF61\u7A32\u306E\u5208\u308A\u53D6\u308A\u8DE1\u306E\u6C34\u7530\u306B\u3044\u308B\u306E\u3060\u304C\u3001\u8349\u306B\u906E\u3089\u308C\u3066\u30AF\u30C1\u30D0\u30B7\u3092\u78BA\u8A8D\u3067\u304D\u306A\u3044\u3002\u4ED8\u8FD1\u306B\u30CF\u30B7\u30DC\u30BD\u3082\u3044\u308B\u305F\u3081\u3001\u30AB\u30A6\u30F3\u30C8\u306F\u751A\u3060\u56F0\u96E3\u3002\u3053\u306E\u7FA4\u308C\u306B\u306F\u30B3\u30AF\u30DE\u30EB\u306F\u3044\u306A\u3044\u307F\u305F\u3044\u3002\u3044\u3066\u3082\u9ED2\u8272\u30BF\u30A4\u30D7\u3060\u3068\u8B58\u5225\u3067\u304D\u306A\u3044\u304B\u3082\u3057\u308C\u306A\u3044\u304C...\u3002\u30BF\u30B2\u30EA\u3068\u30B1\u30EA\u304C\u3044\u305F\u3002",
  "id" : 37011427688591360,
  "created_at" : "2011-02-14 04:53:06 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35310889615896576",
  "text" : "2011.2.9 \u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u306E\u89B3\u5BDF\u306B\u51FA\u304B\u3051\u305F\u3002200\u7FBD\u4F4D\u30AB\u30E9\u30B9\u304C\u7FA4\u308C\u3066\u3044\u305F\u304C\u3001\u30CF\u30B7\u30DC\u30BD\u3070\u304B\u308A\u3002\u3088\u304F\u89B3\u5BDF\u3059\u308B\u3068\u3001\u7FA4\u308C\u306E\u4E00\u89D2\u306B20\u7FBD\u3050\u3089\u3044\u3001\u30AF\u30C1\u30D0\u30B7\u304C\u5C16\u3063\u3066\u3044\u3066\u3001\u5C11\u3057\u5C0F\u67C4\u306A\u30B0\u30EB\u30FC\u30D7\u304C\u3044\u305F\u3002\u30AF\u30C1\u30D0\u30B7\u304C\u306F\u3063\u304D\u308A\u767D\u3044\u3068\u5206\u304B\u308B\u306E\u3082\u3044\u305F\u3002\u9060\u76EE\u306B\u898B\u308B\u3068\u3001\u4F53\u5168\u4F53\u9ED2\u3044\u306E\u3060\u304C\u4F55\u3068\u306A\u304F\u767D\u3063\u307D\u304F\u898B\u3048\u308B\u3002",
  "id" : 35310889615896576,
  "created_at" : "2011-02-09 12:15:46 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35309658122092544",
  "text" : "2011.2.6 \u30DF\u30E4\u30DE\u30AC\u30E9\u30B9\u3092\u6625\u65E5\u90E8\u5E02\u5185\u306E\u6C34\u7530\u5730\u5E2F\u3067\u898B\u3064\u3051\u305F\u3002\u82E6\u7BC03\u5E74\u3001\u3084\u3063\u3068\u78BA\u8A8D\u3067\u304D\u305F\u3002\u305D\u308C\u306B\u3057\u3066\u3082\u30CF\u30B7\u30DC\u30BD\u30AC\u30E9\u30B9\u3068\u306E\u8B58\u5225\u306F\u3080\u3064\u304B\u3057\u3044\u3002\u30AF\u30C1\u30D0\u30B7\u304C\u5C16\u3063\u3066\u3044\u3066\u3001\u767D\u3063\u307D\u3044\u306E\u304C\u7279\u5FB4\u3060\u304C\u3001\u898B\u308B\u89D2\u5EA6\u3084\u65E5\u5149\u306E\u5F53\u305F\u308A\u5177\u5408\u3001\u500B\u4F53\u5DEE\u3092\u8003\u3048\u308B\u3068\u3001\u3060\u3093\u3060\u3093\u81EA\u4FE1\u304C\u306A\u304F\u306A\u3063\u3066\u304F\u308B\u3002",
  "id" : 35309658122092544,
  "created_at" : "2011-02-09 12:10:53 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]