Grailbird.data.tweets_2010_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11290375797",
  "text" : "2010.3.30 \u30A6\u30B0\u30A4\u30B91 \u81EA\u5B85\u5EAD\u3001\u96A3\u5B85\u306E\u30A2\u30AB\u30E1\u306E\u751F\u57A3\u304B\u3089\u98DB\u3073\u51FA\u3057\u3066\u304D\u305F",
  "id" : 11290375797,
  "created_at" : "2010-03-30 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11238211146",
  "text" : "2010.3.29 \u30B3\u30AC\u30E24\u7FBD(\u65E7\u53E4\u9685\u7530\u5DDD)",
  "id" : 11238211146,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10700909364",
  "text" : "2010.3.19 \u30D2\u30E8\u30C9\u30EA2\u7FBD\u304C\u3053\u3053\u6570\u65E5\u300111\u6642\u9803\u306B\u306A\u308B\u3068\u81EA\u5B85\u5EAD\u306B\u6765\u3066\u3001\u5EAD\u6728\u306E\u65B0\u82BD\u3084\u82B1\u3073\u3089\u3092\u3064\u3044\u3070\u3093\u3067\u884C\u304F\u3002",
  "id" : 10700909364,
  "created_at" : "2010-03-19 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10369594874",
  "text" : "2010.3.11 \u30BB\u30B0\u30ED\u30BB\u30AD\u30EC\u30A41 \u8C4A\u6625\u99C5\u524D",
  "id" : 10369594874,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10053365953",
  "text" : "2010.3.5 \u30B8\u30E7\u30A6\u30D3\u30BF\u30AD\u26401(\u81EA\u5B85\u5EAD)",
  "id" : 10053365953,
  "created_at" : "2010-03-06 00:00:00 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]