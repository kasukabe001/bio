Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7939707035983873",
  "text" : "2010.11.25 \u30B8\u30E7\u30A6\u30D3\u30BF\u30AD\u306E\u26421\u7FBD\u521D\u8A8D\u3002 11\/20 12\u6642\u9803 \u3044\u3064\u3082\u306E\u5834\u6240\u306B\u884C\u3063\u305F\u304C\u3001\u30C1\u30E5\u30A6\u30B5\u30AE\u306F\u3044\u306A\u304B\u3063\u305F\u3002",
  "id" : 7939707035983873,
  "created_at" : "2010-11-25 23:32:28 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5802107806425089",
  "text" : "\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u306E\u5852\u3060\u3063\u305F\u30E6\u30EA\u30CE\u30AD\u306E\u679D\u3092\u3059\u3079\u3066\u5207\u308A\u843D\u3068\u3055\u308C\u3066\u3057\u307E\u3063\u305F\u3002\u3053\u306E\u6728\u3060\u3051\u3067\u306A\u304F\u3001\u30E6\u30EA\u30CE\u30AD\u901A\u308A\u306E\u30E6\u30EA\u30CE\u30AD\u5168\u90E8\u304C\u3001\u679D\u6253\u3061\u3055\u308C\u3066\u3057\u307E\u3063\u305F\u3002\u304A\u305D\u3089\u304F\u843D\u3061\u8449\u4E88\u9632\u5BFE\u7B56\u3068\u3057\u3066\u5E02\u304C\u5B9F\u65BD\u3057\u305F\u306E\u3067\u3042\u308D\u3046\u3002\u4E00\u672C\u3050\u3089\u3044\u3001\u8449\u3063\u3071\u3092\u6B8B\u3057\u3066\u304F\u308C\u3066\u3082\u3088\u3055\u305D\u3046\u306B\u601D\u3046\u3002\u5E02\u5F79\u6240\u3068\u304B\u3051\u3042\u3063\u3066\u307F\u308B\u3079\u304D\u3060\u3063\u305F\u3002",
  "id" : 5802107806425089,
  "created_at" : "2010-11-20 01:58:24 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3446714606288896",
  "text" : "2010.11.13 15\u6642 \u30B7\u30E9\u30B5\u30AE\u306E\u5852\u3067\u306F\u3068\u76EE\u3092\u3064\u3051\u3066\u3044\u305F\u5834\u6240\u306B\u51FA\u304B\u3051\u305F\u3002\u3044\u3064\u3082\u30C1\u30E5\u30A6\u30B5\u30AE\u304C1\u7FBD\u3044\u308B\u3002\u7A32\u3092\u5208\u3063\u305F\u6C34\u7530\u3067\u63A1\u990C\u3057\u3066\u3044\u308B\u3002\u3072\u3068\u6708\u3050\u3089\u3044\u524D\u306F\u3001\u3053\u3053\u30673\u7FBD\u306E\u30C1\u30E5\u30A6\u30B5\u30AE\u3092\u78BA\u8A8D\u3057\u3066\u3044\u305F\u3002\u4F55\u3089\u304B\u306E\u7406\u7531\u3067\u6E21\u308A\u304C\u9045\u308C\u3066\u3044\u308B\u4E00\u7FBD\u304C\u5C45\u6B8B\u3063\u3066\u3044\u308B\u306E\u3060\u308D\u3046\u304B\u3002\u30B5\u30AE\u306E\u5074\u3067\u30AD\u30BB\u30AD\u30EC\u30A4\u3092\u898B\u305F\u3002",
  "id" : 3446714606288896,
  "created_at" : "2010-11-13 13:58:55 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2998200923332608",
  "text" : "2010.11.12 16:45 \u5852\u306E\u6728\u306F\u901A\u308A\u306E\u4E00\u756A\u897F\u5074\u3067\u3001\u4E8C\u65B9\u3092\u9053\u8DEF\u306B\u56F2\u307E\u308C\u3001\u5074\u306B\u306F2\u968E\u5EFA\u306E\u5BB6\u306F\u306A\u3044\u3002\u65E5\u5F53\u308A\u304C\u826F\u3044\u304B\u3089\u304B\u8272\u3065\u304F\u306E\u306F\u4ED6\u306E\u8857\u8DEF\u6A39\u3088\u308A\u3082\u969B\u7ACB\u3063\u3066\u9045\u3044\u3002\u7DD1\u306E\u8449\u304C\u305F\u304F\u3055\u3093\u30022008\u5E74\u306B\u3082\u5852\u306B\u306A\u3063\u3066\u3044\u305F\u3002\u65E5\u6CA1\u76F4\u5F8C\u306E10~15\u5206\u306E\u9593\u306B\u5168\u4F53\u306E8~9\u5272\u3050\u3089\u3044\u304C\u96C6\u5408\u3059\u308B\u3088\u3046\u306A\u611F\u3058\u3002",
  "id" : 2998200923332608,
  "created_at" : "2010-11-12 08:16:41 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2720824519823360",
  "text" : "2010.11.11 16:30 \u5852\u306B\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u306F\u3044\u306A\u3044\u3002\u5852\u306E10m\u3050\u3089\u3044\u4E0A\u7A7A\u30923,4\u7FBD\u304C\u98DB\u3093\u3067\u3044\u3063\u305F\u300210\u5206\u3050\u3089\u3044\u5852\u306E\u5074\u3092\u96E2\u308C\u3001\u623B\u3063\u3066\u304D\u305F\u3002\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u306F\u96C6\u307E\u308A\u59CB\u3081\u3066\u304A\u308A\u3001\u9053\u8DEF\u3092\u631F\u3093\u3060\u4F4D\u7F6E\u306B\u3042\u308B\u30D0\u30A4\u30AF\u5C4B\u306E\u5C4B\u6839\u306B20\u7FBD\u8FD1\u304F\u304C\u6B62\u307E\u3063\u305F\u3002\u65E5\u6CA1\u76F4\u5F8C\u306E\u77ED\u6642\u9593\u306B\u96C6\u4E2D\u3057\u3066\u96C6\u307E\u3063\u3066\u6765\u308B\u3002",
  "id" : 2720824519823360,
  "created_at" : "2010-11-11 13:54:29 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2574656699629568",
  "text" : "2010.11.19 16:47,48\u5206\u3000\u5852\u306E\u30E6\u30EA\u30CE\u30AD\u306E\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u304C\u96C6\u307E\u308A\u3060\u3057\u305F\u3002\u307E\u3060\u300110\u7FBD\u5F31\u3002\u3044\u304D\u306A\u308A\u5852\u5165\u308A\u306F\u305B\u305A\u3001\u4ED8\u8FD1\u306E\u96FB\u7DDA\u3084\u6C11\u5BB6\u306E\u5C4B\u6839\u306B\u6B62\u307E\u308B\u3002\u5852\u3068\u9053\u8DEF\u3092\u9694\u3066\u305F\u30D0\u30A4\u30AF\u5C4B\u306E\u5C4B\u6839\u306B\u591A\u304F\u304C\u6B62\u307E\u308A\u3001\u305D\u3053\u304B\u3089\u5852\u5165\u308A\u300210\u5206\u3050\u3089\u3044\u3067\u6570\u306F20\u7FBD\u3050\u3089\u3044\u306B\u306A\u3063\u305F\u3002",
  "id" : 2574656699629568,
  "created_at" : "2010-11-11 04:13:40 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1419243878883328",
  "text" : "2010.11.6 17\u6642\u3001\u65E5\u6CA1\u76F4\u5F8C\u9803\u3002\u30CF\u30AF\u30BB\u30AD\u30EC\u30A4\u304C\u5852\u306E\u5468\u308A\u3092\u98DB\u3073\u56DE\u3063\u3066\u3044\u308B\u3002\u89B3\u5BDF\u4E2D\u306B\u3082\u6B21\u3005\u306B\u98DB\u6765\u3057\u3066\u304F\u308B\u3002\u7DCF\u657030~40\u7FBD\u3050\u3089\u3044\uFF1F\u3002\u679D\u306B\u6B62\u307E\u308B\u3068\u8449\u306E\u9670\u306B\u306A\u308A\u3001\u898B\u3048\u306A\u304F\u306A\u308B\u306E\u3067\u3001\u6B63\u78BA\u306A\u30AB\u30A6\u30F3\u30C8\u306F\u56F0\u96E3\u3002\u98DB\u6765\u3059\u308B\u500B\u4F53\u306F\u7686\u3001\u540C\u3058\u65B9\u89D2\u304B\u3089\u3084\u3063\u3066\u6765\u308B\u306E\u306F\u5076\u7136\u3060\u308D\u3046\u304B\u3002",
  "id" : 1419243878883328,
  "created_at" : "2010-11-07 23:42:28 +0000",
  "user" : {
    "name" : "\u53E4\u9685\u7530\u5DDD",
    "screen_name" : "oldsumida",
    "protected" : false,
    "id_str" : "94947450",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324073690\/hiyodori_normal.gif",
    "id" : 94947450,
    "verified" : false
  }
} ]